# NIVQO iPhone cloud build

This repository contains iPhone source code, not a compiled application.

Open Actions > Build NIVQO iPhone IPA > Run workflow. The Mac runner tests the protocol and builds for a physical iPhone. A successful run produces the NIVQO-iPhone-for-Sideloadly artifact. Download and extract the artifact ZIP, then select the .ipa inside in Sideloadly on Windows.

No Apple credentials are needed in GitHub. Sideloadly signs the IPA locally using your Apple account. Never put Apple passwords in this repository.

The workflow has not yet run. Build errors must be resolved before there is an installable IPA. Physical-device operation remains unverified.
