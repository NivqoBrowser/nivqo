import SwiftUI
import WebKit
import Combine

struct Bookmark: Identifiable, Codable {
    var id = UUID()
    let title: String
    let url: String
}

final class BrowserTab: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate {
    let id = UUID()
    let webView: WKWebView
    let isPrivate: Bool
    @Published var title = "New tab"
    @Published var url: URL?
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var progress = 0.0
    @Published var isLoading = false
    @Published var message: String?
    private var observations: [NSKeyValueObservation] = []

    init(isPrivate: Bool = false) {
        self.isPrivate = isPrivate
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = isPrivate ? .nonPersistent() : .default()
        configuration.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = UIColor(Color.nivqoBackground)
        observations = [
            webView.observe(\.title, options: [.new]) { [weak self] web, _ in self?.title = web.title ?? "New tab" },
            webView.observe(\.url, options: [.new]) { [weak self] web, _ in self?.url = web.url },
            webView.observe(\.canGoBack, options: [.new]) { [weak self] web, _ in self?.canGoBack = web.canGoBack },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] web, _ in self?.canGoForward = web.canGoForward },
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] web, _ in self?.progress = web.estimatedProgress },
            webView.observe(\.isLoading, options: [.new]) { [weak self] web, _ in self?.isLoading = web.isLoading }
        ]
    }
    func load(_ url: URL) {
        guard let safeURL = safeWebURL(url.absoluteString) else { message = "Only http and https pages can be opened."; return }
        self.url = safeURL
        webView.load(URLRequest(url: safeURL))
    }
    func search(_ input: String) {
        let value = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        if let direct = safeWebURL(value) { load(direct); return }
        if !value.contains(" "), !value.contains(":"), value.contains("."), let direct = safeWebURL("https://" + value) {
            load(direct); return
        }
        var components = URLComponents(string: "https://duckduckgo.com/")!
        components.queryItems = [URLQueryItem(name: "q", value: value)]
        if let url = components.url { load(url) }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if safeWebURL(url.absoluteString) != nil || url.absoluteString == "about:blank" {
            decisionHandler(.allow)
        } else {
            if navigationAction.targetFrame?.isMainFrame != false { message = "This link uses a scheme that NIVQO does not open." }
            decisionHandler(.cancel)
        }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { handle(error) }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { handle(error) }
    private func handle(_ error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { message = error.localizedDescription }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { message = "This page stopped responding. Reload to continue." }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url { load(url) }
        return nil
    }
}

final class BrowserModel: ObservableObject {
    @Published var tabs: [BrowserTab]
    @Published var selectedID: UUID
    @Published var bookmarks: [Bookmark]
    private var tabObservers: [UUID: AnyCancellable] = [:]
    private func observe(_ tab: BrowserTab) { tabObservers[tab.id] = tab.objectWillChange.sink { [weak self] in self?.objectWillChange.send() } }
    init() {
        let first = BrowserTab()
        tabs = [first]; selectedID = first.id
        bookmarks = (UserDefaults.standard.data(forKey: "nivqo.bookmarks").flatMap { try? JSONDecoder().decode([Bookmark].self, from: $0) } ?? []).filter { safeWebURL($0.url) != nil }
        observe(first)
    }
    var selected: BrowserTab { tabs.first(where: { $0.id == selectedID }) ?? tabs[0] }
    func newTab(privateMode: Bool = false, url: URL? = nil) {
        let tab = BrowserTab(isPrivate: privateMode)
        tabs.append(tab); observe(tab); selectedID = tab.id
        if let url = url { tab.load(url) }
    }
    func close(_ id: UUID) {
        tabs.first(where: { $0.id == id })?.webView.stopLoading()
        tabs.removeAll { $0.id == id }; tabObservers.removeValue(forKey: id)
        if tabs.isEmpty { let tab = BrowserTab(); tabs = [tab]; observe(tab) }
        if !tabs.contains(where: { $0.id == selectedID }) { selectedID = tabs[0].id }
    }
    func bookmarkCurrent() {
        guard let url = selected.url, safeWebURL(url.absoluteString) != nil,
              !bookmarks.contains(where: { $0.url == url.absoluteString }) else { return }
        bookmarks.append(Bookmark(title: selected.title, url: url.absoluteString)); saveBookmarks()
    }
    func removeBookmarks(at offsets: IndexSet) { bookmarks.remove(atOffsets: offsets); saveBookmarks() }
    private func saveBookmarks() { if let data = try? JSONEncoder().encode(bookmarks) { UserDefaults.standard.set(data, forKey: "nivqo.bookmarks") } }
    func clearWebsiteData() {
        for tab in tabs { tab.webView.stopLoading() }
        WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) {}
        tabObservers.removeAll(); let fresh = BrowserTab(); tabs = [fresh]; observe(fresh); selectedID = fresh.id
    }
}
