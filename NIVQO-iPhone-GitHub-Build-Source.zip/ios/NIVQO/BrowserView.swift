import SwiftUI
import WebKit

struct BrowserView: View {
    @ObservedObject var browser: BrowserModel
    @ObservedObject var flow: FlowClient
    @State private var showingFlow = false
    @State private var showingTabs = false
    @State private var showingBookmarks = false
    @State private var clearConfirmation = false
    @State private var panel: String?
    private var accent: Color { Color(spaceHex: browser.activeSpace.hex) }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("NIVQO").font(.headline).tracking(2)
                Spacer()
                Button { panel = "spaces" } label: { Label(browser.activeSpace.name, systemImage: "circle.fill").font(.subheadline.bold()).foregroundStyle(accent) }
                if browser.selected.isPrivate { Image(systemName: "eye.slash").accessibilityLabel("Private tab") }
            }.padding(.horizontal, 20).padding(.top, 12)
            BrowserPage(tab: browser.selected, browser: browser, openFlow: { showingFlow = true }, openPanel: { panel = $0 })
            HStack(spacing: 12) {
                Button { browser.selected.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!browser.selected.canGoBack).accessibilityLabel("Back")
                Button { browser.selected.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!browser.selected.canGoForward).accessibilityLabel("Forward")
                Spacer(minLength: 0)
                Button { showingFlow = true } label: {
                    Image(systemName: "arrow.up.right.square")
                        .overlay(alignment: .topTrailing) { if !flow.incoming.isEmpty { Circle().fill(.orange).frame(width: 8, height: 8).offset(x: 5, y: -4) } }
                }.accessibilityLabel("Flow and Drop")
                Button { browser.newTab() } label: { Image(systemName: "house") }.accessibilityLabel("New home tab")
                Button { showingTabs = true } label: { Text(String(browser.visibleTabs.count)).font(.caption.bold()).frame(width: 23, height: 23).overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1.5)) }.accessibilityLabel("\(browser.visibleTabs.count) tabs")
                Menu {
                    Button("New tab", systemImage: "plus") { browser.newTab() }
                    Button("New private tab", systemImage: "eye.slash") { browser.newTab(privateMode: true) }
                    Button("Save bookmark", systemImage: "bookmark") { browser.bookmarkCurrent() }.disabled(browser.selected.url == nil || browser.selected.isPrivate)
                    Button("Bookmarks", systemImage: "book") { showingBookmarks = true }
                    Button("Spaces", systemImage: "square.grid.2x2") { panel = "spaces" }
                    Button("History", systemImage: "clock") { panel = "history" }
                    Button("Import & saved accounts", systemImage: "square.and.arrow.down") { panel = "imports" }
                    Button("Shield & privacy", systemImage: "shield") { panel = "privacy" }
                    Button("Assist · read page", systemImage: "sparkles") { panel = "assist" }
                    Button("Settings & updates", systemImage: "gearshape") { panel = "settings" }
                    if let url = browser.selected.url { ShareLink(item: url) { Label("Share page", systemImage: "square.and.arrow.up") } }
                    Button("Clear website data", systemImage: "trash", role: .destructive) { clearConfirmation = true }
                } label: { Image(systemName: "ellipsis.circle") }.accessibilityLabel("Browser menu")
            }
            .font(.title3).padding(.horizontal, 20).frame(minHeight: 54).background(Color.nivqoPanel)
        }
        .padding(4).background(Color.nivqoBackground)
        .overlay { Rectangle().strokeBorder(accent, lineWidth: 4).allowsHitTesting(false) }.tint(accent)
        .sheet(isPresented: Binding(get: { panel != nil }, set: { if !$0 { panel = nil } })) { BrowserPanels(browser: browser, panel: panel ?? "settings").tint(accent) }
        .alert("NIVQO", isPresented: Binding(get: { browser.notice != nil }, set: { if !$0 { browser.notice = nil } })) { Button("OK") { browser.notice = nil } } message: { Text(browser.notice ?? "") }
        .sheet(isPresented: $showingFlow) { FlowView(flow: flow, browser: browser) }
        .sheet(isPresented: $showingTabs) {
            NavigationStack {
                List {
                    ForEach(browser.visibleTabs) { tab in
                        HStack {
                            Button {
                                browser.select(tab); showingTabs = false
                            } label: {
                                Label(tab.title, systemImage: tab.isPrivate ? "eye.slash" : "globe").lineLimit(2)
                            }
                            Spacer()
                            Button { browser.close(tab.id) } label: { Image(systemName: "xmark.circle") }.buttonStyle(.borderless).accessibilityLabel("Close \(tab.title)")
                        }.padding(.vertical, 8)
                    }
                }.navigationTitle("Your tabs")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) { Button("Done") { showingTabs = false } }
                        ToolbarItem(placement: .navigationBarTrailing) { Button("New tab") { browser.newTab(); showingTabs = false } }
                    }
            }
        }
        .sheet(isPresented: $showingBookmarks) {
            NavigationStack {
                List {
                    if browser.visibleBookmarks.isEmpty { Text("Save a page from the browser menu to find it here.").foregroundStyle(.secondary) }
                    ForEach(browser.visibleBookmarks) { bookmark in
                        Button {
                            if let url = safeWebURL(bookmark.url) { browser.selected.load(url) }
                            showingBookmarks = false
                        } label: {
                            VStack(alignment: .leading, spacing: 6) { Text(bookmark.title).foregroundStyle(.primary); Text(bookmark.url).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                        }
                    }.onDelete(perform: browser.removeBookmarks)
                }.navigationTitle("Bookmarks").toolbar { Button("Done") { showingBookmarks = false } }
            }
        }
        .confirmationDialog("Clear cookies, caches and website data, and close all tabs? Bookmarks will remain.", isPresented: $clearConfirmation, titleVisibility: .visible) {
            Button("Clear website data", role: .destructive) { browser.clearWebsiteData() }
        }
    }
}

private struct BrowserPage: View {
    @ObservedObject var tab: BrowserTab
    @ObservedObject var browser: BrowserModel
    let openFlow: () -> Void
    let openPanel: (String) -> Void
    @State private var address = ""
    @FocusState private var editing: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: tab.isPrivate ? "eye.slash" : (tab.url?.scheme == "https" ? "lock" : "globe"))
                    .foregroundStyle(Color.nivqoCyan)
                TextField("Search or enter a website", text: $address)
                    .keyboardType(.webSearch).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.go).focused($editing)
                    .onSubmit { browser.search(address); editing = false }
                    .accessibilityLabel("Website address or search")
                Button {
                    if tab.isLoading { tab.webView.stopLoading() } else if tab.url != nil { tab.webView.reload() }
                } label: { Image(systemName: tab.isLoading ? "xmark" : "arrow.clockwise") }.accessibilityLabel(tab.isLoading ? "Stop loading" : "Reload page")
            }.padding(14).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)).padding(12)
            if tab.isLoading { ProgressView(value: tab.progress).tint(.nivqoCyan).frame(height: 2) }
            if tab.url == nil {
                ScrollView {
                    VStack(spacing: 26) {
                        Image("Brand").resizable().scaledToFit().frame(width: 76, height: 76).padding(.top, 26)
                        VStack(spacing: 12) {
                            Text("N I V Q O").font(.largeTitle.bold())
                            Text("The web, on your terms.").font(.title3.weight(.semibold))
                            Text(tab.isPrivate ? "PRIVATE TAB · NO PERSISTENT WEBSITE STORAGE" : "BROWSE FREELY. STAY PRIVATE.").font(.caption2.weight(.semibold)).tracking(1.5).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        Button { editing = true } label: { Label("Search anything or enter a URL", systemImage: "magnifyingglass").font(.subheadline).frame(maxWidth: .infinity).padding(18).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)) }.padding(.horizontal, 24)
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                            feature("Flow + Drop", "Move tabs & files", "qrcode.viewfinder", openFlow)
                            feature("Spaces", "Separate identities", "square.grid.2x2") { openPanel("spaces") }
                            feature("Shield", "Privacy controls", "shield") { openPanel("privacy") }
                            feature("Assist", "Local reading tools", "sparkles") { openPanel("assist") }
                        }.padding(.horizontal, 24)
                        HStack(spacing: 24) {
                            shortcut("Wikipedia", symbol: "book", url: "https://wikipedia.org")
                            shortcut("GitHub", symbol: "chevron.left.forwardslash.chevron.right", url: "https://github.com")
                            shortcut("Proton", symbol: "envelope", url: "https://mail.proton.me")
                        }
                        Button { openPanel("imports") } label: { Label("Import bookmarks & saved passwords", systemImage: "square.and.arrow.down").font(.subheadline) }
                        Text("\(browser.activeSpace.name) Space · \(tab.isPrivate ? "Temporary private session" : "Separate website session")\nFlow uses your local network and no NIVQO account.")
                            .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(.horizontal, 30)
                    }.padding(.bottom, 30).frame(maxWidth: .infinity)
                }
            } else { WebPage(webView: tab.webView).id(tab.id) }
        }
        .onAppear { address = tab.url?.absoluteString ?? "" }
        .onChange(of: tab.id) { _ in address = tab.url?.absoluteString ?? "" }
        .onChange(of: tab.url) { url in if !editing { address = url?.absoluteString ?? "" } }
        .alert("NIVQO", isPresented: Binding(get: { tab.message != nil }, set: { if !$0 { tab.message = nil } })) { Button("OK") { tab.message = nil } } message: { Text(tab.message ?? "") }
    }
    private func feature(_ title: String, _ detail: String, _ symbol: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) { VStack(spacing: 10) {
            Image(systemName: symbol).font(.title2)
            Text(title).font(.subheadline.bold())
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, minHeight: 106).padding(8).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)) }
    }
    private func shortcut(_ name: String, symbol: String, url: String) -> some View {
        Button { if let url = URL(string: url) { tab.load(url) } } label: {
            VStack(spacing: 10) { Image(systemName: symbol).font(.title2).frame(width: 50, height: 50).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)); Text(name).font(.caption) }
        }
    }
}

extension Color {
    init(spaceHex: String) {
        let value = UInt32(spaceHex, radix: 16) ?? 0x27c9ff
        self.init(red: Double((value >> 16) & 255)/255, green: Double((value >> 8) & 255)/255, blue: Double(value & 255)/255)
    }
}

private struct WebPage: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
