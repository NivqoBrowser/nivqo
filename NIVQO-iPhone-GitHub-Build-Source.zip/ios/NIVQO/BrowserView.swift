import SwiftUI
import WebKit

struct BrowserView: View {
    @ObservedObject var browser: BrowserModel
    @ObservedObject var flow: FlowClient
    @State private var showingFlow = false
    @State private var showingTabs = false
    @State private var showingBookmarks = false
    @State private var clearConfirmation = false

    var body: some View {
        VStack(spacing: 0) {
            BrowserPage(tab: browser.selected, openFlow: { showingFlow = true })
            HStack(spacing: 28) {
                Button { browser.selected.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!browser.selected.canGoBack).accessibilityLabel("Back")
                Button { browser.selected.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!browser.selected.canGoForward).accessibilityLabel("Forward")
                Spacer(minLength: 0)
                Button { showingFlow = true } label: {
                    Image(systemName: "arrow.up.right.square")
                        .overlay(alignment: .topTrailing) { if !flow.incoming.isEmpty { Circle().fill(.orange).frame(width: 8, height: 8).offset(x: 5, y: -4) } }
                }.accessibilityLabel("Flow and Drop")
                Button { showingTabs = true } label: { Text(String(browser.tabs.count)).font(.caption.bold()).frame(width: 23, height: 23).overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1.5)) }.accessibilityLabel("\(browser.tabs.count) tabs")
                Menu {
                    Button("New tab", systemImage: "plus") { browser.newTab() }
                    Button("New private tab", systemImage: "eye.slash") { browser.newTab(privateMode: true) }
                    Button("Save bookmark", systemImage: "bookmark") { browser.bookmarkCurrent() }.disabled(browser.selected.url == nil)
                    Button("Bookmarks", systemImage: "book") { showingBookmarks = true }
                    Button("Clear website data", systemImage: "trash", role: .destructive) { clearConfirmation = true }
                } label: { Image(systemName: "ellipsis.circle") }.accessibilityLabel("Browser menu")
            }
            .font(.title3).padding(.horizontal, 20).frame(minHeight: 54).background(Color.nivqoPanel)
        }
        .background(Color.nivqoBackground)
        .sheet(isPresented: $showingFlow) { FlowView(flow: flow, browser: browser) }
        .sheet(isPresented: $showingTabs) {
            NavigationStack {
                List {
                    ForEach(browser.tabs) { tab in
                        HStack {
                            Button {
                                browser.selectedID = tab.id; showingTabs = false
                            } label: {
                                Label(tab.title, systemImage: tab.isPrivate ? "eye.slash" : "globe").lineLimit(2)
                            }
                            Spacer()
                            Button { browser.close(tab.id) } label: { Image(systemName: "xmark.circle") }.buttonStyle(.borderless).accessibilityLabel("Close \(tab.title)")
                        }.padding(.vertical, 8)
                    }
                }.navigationTitle("Your tabs")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) { Button("Done") { showingTabs = false } }
                        ToolbarItem(placement: .navigationBarTrailing) { Button("New tab") { browser.newTab(); showingTabs = false } }
                    }
            }
        }
        .sheet(isPresented: $showingBookmarks) {
            NavigationStack {
                List {
                    if browser.bookmarks.isEmpty { Text("Save a page from the browser menu to find it here.").foregroundStyle(.secondary) }
                    ForEach(browser.bookmarks) { bookmark in
                        Button {
                            if let url = safeWebURL(bookmark.url) { browser.selected.load(url) }
                            showingBookmarks = false
                        } label: {
                            VStack(alignment: .leading, spacing: 6) { Text(bookmark.title).foregroundStyle(.primary); Text(bookmark.url).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                        }
                    }.onDelete(perform: browser.removeBookmarks)
                }.navigationTitle("Bookmarks").toolbar { Button("Done") { showingBookmarks = false } }
            }
        }
        .confirmationDialog("Clear cookies, caches and website data, and close all tabs? Bookmarks will remain.", isPresented: $clearConfirmation, titleVisibility: .visible) {
            Button("Clear website data", role: .destructive) { browser.clearWebsiteData() }
        }
    }
}

private struct BrowserPage: View {
    @ObservedObject var tab: BrowserTab
    let openFlow: () -> Void
    @State private var address = ""
    @FocusState private var editing: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: tab.isPrivate ? "eye.slash" : (tab.url?.scheme == "https" ? "lock" : "globe"))
                    .foregroundStyle(Color.nivqoCyan)
                TextField("Search or enter a website", text: $address)
                    .keyboardType(.webSearch).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.go).focused($editing)
                    .onSubmit { tab.search(address); editing = false }
                    .accessibilityLabel("Website address or search")
                Button {
                    if tab.isLoading { tab.webView.stopLoading() } else if tab.url != nil { tab.webView.reload() }
                } label: { Image(systemName: tab.isLoading ? "xmark" : "arrow.clockwise") }.accessibilityLabel(tab.isLoading ? "Stop loading" : "Reload page")
            }.padding(14).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)).padding(12)
            if tab.isLoading { ProgressView(value: tab.progress).tint(.nivqoCyan).frame(height: 2) }
            if tab.url == nil {
                ScrollView {
                    VStack(spacing: 26) {
                        Image("Brand").resizable().scaledToFit().frame(width: 82, height: 82).padding(.top, 48)
                        VStack(spacing: 12) {
                            Text("N I V Q O").font(.largeTitle.bold())
                            Text("The web, on your terms.").font(.title3.weight(.semibold))
                            Text(tab.isPrivate ? "PRIVATE TAB · NO PERSISTENT WEBSITE STORAGE" : "BROWSE FREELY. STAY PRIVATE.").font(.caption2.weight(.semibold)).tracking(1.5).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        Button(action: openFlow) {
                            VStack(spacing: 10) {
                                Image(systemName: "qrcode.viewfinder").font(.largeTitle)
                                Text("Flow + Drop").font(.headline)
                                Text("Scan. Pair. Move tabs and files.").font(.subheadline)
                            }.frame(maxWidth: .infinity).padding(24).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 20))
                        }.padding(.horizontal, 24)
                        HStack(spacing: 24) {
                            shortcut("Wikipedia", symbol: "book", url: "https://wikipedia.org")
                            shortcut("GitHub", symbol: "chevron.left.forwardslash.chevron.right", url: "https://github.com")
                            shortcut("Proton", symbol: "envelope", url: "https://mail.proton.me")
                        }
                        Text("\(tab.isPrivate ? "Private tabs use temporary website storage. " : "")Bookmarks stay on this iPhone. Flow uses your local network and no NIVQO account.")
                            .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(.horizontal, 30)
                    }.padding(.bottom, 30).frame(maxWidth: .infinity)
                }
            } else { WebPage(webView: tab.webView) }
        }
        .onAppear { address = tab.url?.absoluteString ?? "" }
        .onChange(of: tab.id) { _ in address = tab.url?.absoluteString ?? "" }
        .onChange(of: tab.url) { url in if !editing { address = url?.absoluteString ?? "" } }
        .alert("NIVQO", isPresented: Binding(get: { tab.message != nil }, set: { if !$0 { tab.message = nil } })) { Button("OK") { tab.message = nil } } message: { Text(tab.message ?? "") }
    }
    private func shortcut(_ name: String, symbol: String, url: String) -> some View {
        Button { if let url = URL(string: url) { tab.load(url) } } label: {
            VStack(spacing: 10) { Image(systemName: symbol).font(.title2).frame(width: 50, height: 50).background(Color.nivqoPanel).clipShape(RoundedRectangle(cornerRadius: 16)); Text(name).font(.caption) }
        }
    }
}

private struct WebPage: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
