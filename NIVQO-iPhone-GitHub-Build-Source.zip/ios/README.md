# NIVQO iPhone source — v0.7 alpha

This is a native SwiftUI / WKWebView iPhone application, with an Xcode project. It includes tabs, private tabs, bookmarks, QR camera scanning, and a client for the desktop Flow + Drop encrypted LAN protocol. No cloud service or third-party Swift package is needed.

**Build status:** Source prepared on Windows. It has not been compiled, signed or tested on an iPhone. There is no built `.ipa` in this delivery. The Xcode build and the included CryptoKit interoperability tests must pass on a Mac before treating it as a working device release.

## Install on your own iPhone

1. Copy this `ios` folder to a Mac with Xcode compatible with your iPhone's installed iOS version. The project targets iOS 17 or later.
2. Open `NIVQO.xcodeproj` in Xcode. Select the **NIVQO** target → **Signing & Capabilities**. Choose your Apple development team and enable automatic signing. Set a unique bundle identifier if the default is unavailable, then keep it stable for future updates.
3. Connect your iPhone to that Mac and complete Apple's device trust / Developer Mode steps yourself when requested.
4. Select your iPhone as the run destination and press **Run**. Xcode builds, signs and installs the app if provisioning and compilation succeed.
5. Development provisioning expires; use the expiry shown by Xcode and re-sign when needed. A free Personal Team can have restrictions. For an exported IPA to other registered devices, use the Apple Developer Program and Xcode's registered-device distribution route with the appropriate provisioning profile.

This is development sideloading onto a device you control. The source does not bypass Apple signing, create a universal unsigned IPA, or configure an alternative app marketplace. A Windows installer cannot install the iPhone app. Keep the same signing identity/bundle identifier for updates; deleting the app can delete its local bookmarks and website data.

Apple references: [Run an app on a device](https://help.apple.com/xcode/mac/current/en.lproj/dev5a825a1ca.html), [Signing workflow](https://help.apple.com/xcode/mac/current/en.lproj/dev60b6fbbc7.html), [Developer Mode](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device/), [Registered-device distribution](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices).

## Pair with the Windows desktop

1. Connect both devices to the same trusted private Wi-Fi network. Guest Wi-Fi/client isolation, VPNs, firewalls and an incorrectly selected network adapter may prevent a connection.
2. In desktop NIVQO v0.7, open **Flow + Drop → Create pairing QR**. The QR expires after two minutes.
3. On iPhone, open **Flow + Drop → Scan desktop QR**. Grant camera access if you want to scan; pasting the pairing code works without camera access. Review the detected LAN address and tap **Pair with computer**.
4. iOS asks for Local Network access when needed. Handle that system request yourself. See [Apple local network privacy](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy).
5. Send a normal tab, text, or a file up to 4 MiB in either direction. Incoming items require explicit acceptance: opening a tab, copying text, or selecting a save destination. Private tabs cannot be sent.

Keep the iPhone app in the foreground. Moving it to the background disconnects and clears the pending transfer queue; pair again after returning. The desktop hosts the connection; this version of the iPhone app joins it. Phone-to-phone hosting, background transfers, cookie/session transfer, and internet relay are not included.

## Validate on a Mac before release

From this folder:

```sh
swift test
xcodebuild -project NIVQO.xcodeproj -scheme NIVQO -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

The Swift package tests only `FlowProtocol.swift`. Its fixture was generated with Node X25519 / HKDF / HMAC / AES-GCM, matching the desktop protocol. Tests compare key derivation and proof bytes, decrypt the Node frame, reject tampering/replay, and validate pairing addresses and payloads. Passing these tests does not replace a real desktop-to-iPhone connection and transfer test. Camera scanning and local-network permissions require a physical device test.

Test browsing, back/forward, tabs, bookmarks, private storage, permission denial, QR expiry, disconnects, non-ASCII text, empty files, maximum-size files, incoming acceptance/decline, cancelled saves and app backgrounding. An optional macOS workflow is included at the bundle root; it has not been run here.

## Limits and privacy

This is an alpha companion browser. It uses Apple's WKWebView, not the desktop Chromium engine, and does not implement desktop Shield's tracker filter lists, Spaces, desktop password imports, password autofill, download management or browser history sync. Bookmarks are local; ordinary website data is persistent and private tabs use a nonpersistent store. The browser allows ordinary HTTP pages within WKWebView; HTTP pages do not provide HTTPS transport protection. Flow itself encrypts the LAN payloads. The protocol and native app have not received an independent security audit.

Camera input is used locally to decode pairing codes, without uploading video. The app connects only to a literal private LAN IPv4 address from the pairing code. Pairing secrets are temporary and should be shared only with the intended device. Incoming text copied on acceptance stays local to the iPhone clipboard and has a two-minute expiry.

The project has a bundled NIVQO brand image. Add your final 1024-pixel app icon in Xcode's asset catalog before wider distribution; the current development target uses the system's default app icon.
