#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v npm >/dev/null 2>&1; then
  echo 'Install Node.js 22 or later from https://nodejs.org first.'
  exit 1
fi
echo '[1/3] Installing Electron and build tools (internet required)'
npm install --no-audit --no-fund
echo '[2/3] Checking code and transfer tests'
npm run verify
echo '[3/3] Creating unsigned Intel and Apple Silicon alpha DMG files'
export CSC_IDENTITY_AUTO_DISCOVERY=false
# Local test builds do not sign or notarize.
npm run dist:mac
echo 'Finished. Look in the dist folder for .dmg files.'
echo 'These alpha packages are UNSIGNED and NOT notarised for normal public installation.'
