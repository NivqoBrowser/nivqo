@echo off
setlocal
cd /d "%~dp0"
title NIVQO Alpha - Windows Build
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: Install Node.js 22 or later from https://nodejs.org first.
  pause
  exit /b 1
)
echo [1/3] Installing project dependencies; internet is required.
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
echo [2/3] Checking code and transfer tests.
call npm run verify
if errorlevel 1 goto failed
echo [3/3] Packaging Windows x64 installer.
call npm run dist:win -- --publish never
if errorlevel 1 goto failed
echo.
echo Finished. Open the dist folder for the .exe installer.
echo IMPORTANT: This is an unsigned, experimental browser; it is not a verified production build.
pause
exit /b 0
:failed
echo.
echo Build failed. Scroll up to find the error.
pause
exit /b 1
