# Nivqo Browser prototype — privacy and security notes

**This experimental build is not a privacy guarantee or security-audited browser.**

- App developer telemetry: none intentionally implemented. No registration, analytics endpoint, account or server is included.
- Browsing history and bookmarks: local JSON in Electron's user-data directory, unless history saving is switched off. Cookies, cache and website storage are handled by Chromium.
- Search: the chosen search provider (DuckDuckGo default) receives search terms and connections.
- Websites: websites can still log IP addresses, fingerprint browsers and track users across sessions. Browser features do not anonymise your IP.
- Ads and trackers: the built-in domain fallback blocks a limited list; Ghostery's full filter list engine loads cached rules or downloads public filters. This is URL-based request filtering rather than complete ad removal or anti-fingerprinting.
- Filter downloads: contact filter list hosts without sending your browsing history. For sensitive use, users should inspect all third-party dependencies.
- Private mode: no Nivqo bookmarks/history/session restore for private tabs; site data is stored in a temporary Chromium session and cleared when the last private tab closes. Downloads and server-side website records may remain. Private tabs do not anonymise internet connections.
- WebRTC: Chromium is requested to disable non-proxied UDP candidates to reduce IP leakage; test this per platform.
- DNT/GPC: the browser signals these preferences. They are not enforced server-side.
- Site permissions: default deny, which can break camera/microphone, location, clipboard and some login flows.
- No automatic browser updates, no third-party cookie assurance, no Safe Browsing integration. Known and unknown vulnerabilities may exist. **Do not use as a main browser until independently tested.**

## NIVQO v0.7 account-free handoff

- Flow / Drop operate only between a desktop host and a compatible desktop or native iPhone client on a reachable private IPv4 LAN, not across the public internet.
- A manually shared one-time secret binds an ephemeral X25519 key exchange; transfer frames use authenticated AES-256-GCM and ordered counters. The source design is unaudited.
- The pairing code expires after two minutes and should be handled as a temporary password. There is no persistent pairing identity or automatic reconnection.
- Tab handoff sends URL, title and approximate scroll offset, **never** cookies, session tokens, passwords, history or form input. Don't use the feature for sensitive URLs that contain access tokens in their query strings.
- Text and files under 4 MiB are transferred over the encrypted LAN channel and require explicit recipient approval. Files aren't scanned for malware.
- The browser does not run a generative AI model. NIVQO Assist selects headings and existing sentences locally after you click its button, and does not upload extracted content to an NIVQO server.

## v0.7 imports, QR codes and updates

- Bookmark and password imports read only a file explicitly selected in a native dialog, then show a preview before saving. No other browser database is automatically scanned.
- Saved passwords are encrypted with the operating system account's secure storage via Electron safeStorage in accounts-v1.json. Website, account label, username and Space remain local plaintext metadata. No password or encrypted password is sent to the renderer. The original exported CSV remains plaintext and is not changed or removed by NIVQO.
- Password copy is explicit. The clipboard is cleared after 30 seconds only if unchanged; operating-system clipboard history or other clipboard managers may retain previous contents. Passwords are not automatically filled into web pages.
- QR images are generated and decoded locally. They contain the same temporary pairing secret as the manual code; no third-party QR web service is used. PNG QR imports are bounded by size/dimensions and must decode to a private-LAN NIVQO pairing code.
- Updates are manual installers. No update server is contacted and no new installer is automatically downloaded or run.
- The separately supplied iPhone source uses WKWebView and CryptoKit. Its camera feed stays on the device for QR decoding; local-network access is needed for Flow. It has not been compiled or tested on iPhone in this Windows delivery. See ios/README.md in the complete bundle for capabilities and limitations.