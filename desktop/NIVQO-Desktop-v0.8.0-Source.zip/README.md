# NIVQO Desktop v0.8.0 — Unified Design

Same NIVQO visual language as the iPhone beta concept, with desktop-native horizontal tabs, top address bar, compact chrome, slim per-Space accents, one-click Flow and Spaces, and the approved cyan/blue N logo.

This desktop build is based on the earlier v0.7.1 browser, preserving its local Flow + Drop pairing protocol, separate Space partitions, bookmarks, saved-account imports and privacy controls. It is not a release of full cloud account or bookmark synchronisation.

**Existing installs:** appId `dev.nivqo.browseralpha` has not changed; do not uninstall the current build before updating if you want to preserve your profile.

**Build:** `npm ci && npm run verify && npm run dist:win -- --publish never`. Windows installer is unsigned unless code signing is configured.

---

# NIVQO Desktop v0.7

A Windows/macOS Electron browser alpha. v0.7 adds clearer home and panel spacing, QR-enabled local Flow + Drop, previewed bookmark/password imports and a manual update guide.

## Run and build

Use Node.js 22 or later. Run npm ci, npm run verify, then npm start. To build a Windows x64 installer, run npm run dist:win -- --publish never, or use BUILD-WINDOWS-11.bat. The installer appears in dist/. It is unsigned unless you configure and verify code signing.

## New features

- Search, feature cards, quick access and panels use consistent spacing and readable text. Smaller windows scroll rather than shrinking all content.
- Flow + Drop creates a temporary pairing QR. The native iPhone source in ../ios can scan and join it once built and signed on a Mac. Another desktop can read a PNG QR or paste the code. QR generation and decoding stay local.
- Pairing lasts two minutes. The transfer protocol uses X25519, HKDF, HMAC and AES-GCM with ordered frames. Transfers require receipt approval. The file limit is 4 MiB; both devices need the same local network. This alpha transport has not been independently audited.
- Import & saved accounts accepts bookmark HTML/Chromium JSON and password CSV exports. Preview before committing. Passwords use Electron safeStorage encryption; metadata remains local plaintext. Copy a credential explicitly, then paste it when signing in. There is no automatic form filling or cookie/session import.
- Version & updates shows the version and local profile path. Updates use a new manual installer under the same Windows account and installation location. No background updater is configured.

The established Spaces, private tabs, local history, downloads, offline reading brief and tracker-blocking features remain. This is an experimental browser, not an audited anonymity product.

## Guides

- docs/IMPORTS.md: supported exports, duplicate rules, secure-storage behavior and limitations.
- docs/UPDATES.md: manual upgrades, profile preservation, Windows builds, checksums and optional GitHub build workflow.
- ../ios/README.md: native iPhone source, development signing, QR pairing and pending Mac/device tests.
- PRIVACY.md: data/network behavior, updated with v0.7 additions.

The original v0.6 source ZIP is separate and unchanged. The supplied v0.7 Windows installer has been built on Windows; the iPhone app has not been compiled or signed here. Refer to the delivered verification report for the exact checks performed.
