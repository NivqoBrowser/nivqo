# Start here — NIVQO v0.7

For Windows use the separately delivered NIVQO-Browser-0.7.0-win-x64.exe installer. Close your existing NIVQO before upgrading; retain the same Windows account and installation location. The installer is unsigned. Keep a profile backup before an upgrade.

To run source: install Node.js 22 or later, open this folder in a terminal, run npm ci, then npm start. BUILD-WINDOWS-11.bat performs installation of locked dependencies, verification and packaging. It does not install the generated app or publish a release.

On the home screen, choose Import bookmarks & passwords to import browser export files. Choose Flow + Drop to generate a QR or pair with another device. Choose Version & updates to see the current version and profile folder.

The iPhone project is in ../ios in the complete source bundle. It needs Xcode on a Mac and your own signing team before installation on an iPhone. No compiled iPhone IPA is included.

Read README.md and docs/UPDATES.md for the detailed workflow.
