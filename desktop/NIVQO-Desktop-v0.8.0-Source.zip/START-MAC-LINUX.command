#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22 or newer from https://nodejs.org"
  exit 1
fi
if [ ! -d node_modules/electron ]; then
  echo "Installing Nivqo dependencies for the first time..."
  npm install || exit 1
fi
npm start
