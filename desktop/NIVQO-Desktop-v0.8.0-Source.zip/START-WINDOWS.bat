@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or newer is required. Download from https://nodejs.org
  pause
  exit /b 1
)
if not exist "node_modules\electron" (
  echo Installing Nivqo dependencies for the first time...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed. Check your internet connection.
    pause
    exit /b 1
  )
)
call npm start
if errorlevel 1 pause
