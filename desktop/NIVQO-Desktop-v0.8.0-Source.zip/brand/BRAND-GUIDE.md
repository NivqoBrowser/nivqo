# NIVQO — provisional brand direction (v0.3)

**Status:** Design exploration, not approved for public commercial use. An exact-name company exists in the Czech Republic; trademark risk has not been assessed.

## Positioning

A focused, beautiful, Chromium-based browser project that prioritises responsive navigation, user control and a quieter web. Do not imply zero tracking, guaranteed anonymity or full Chrome compatibility.

## Identity

- Working name: **NIVQO Browser**
- Core line: **Browse freely. Stay private.**
- Launch concept headline: **The web. Reimagined.**
- Voice: simple, precise, calm, confident; no absolute claims like “100% private” or “untraceable”.
- Logo: an original gradient N ribbon symbol on a dark rounded-square tile. The icon should still work at 32px and in monochrome.

## Palette

| Swatch | Hex | Use |
| --- | --- | --- |
| Midnight | `#060B17` | App background |
| Ink | `#0C1424` | Browser chrome |
| Electric Blue | `#3287FF` | Navigation & interaction |
| Cyan | `#21C9FF` | Privacy status & highlights |
| Soft White | `#F5F9FF` | Headings |
| Slate | `#8FA5BD` | Secondary text |

## Interface rules

1. Centre the address bar; reserve highest hierarchy for tabs and content.
2. Use rounded 10–15px controls and restrained borders.
3. Dark theme is the visual signature; light theme is supported.
4. Never confuse a decorative shield with a verified site security assessment.
5. Accessibility: keyboard operation, visible focus indicators and readable contrast.
6. Avoid using other companies' logos or branded UI assets unless their use is permitted.

## Brand deliverables

- `assets/nivqo-icon.svg` — scalable vector N.
- `assets/nivqo-icon-256.png` and `nivqo-icon-512.png` — icon exports.
- `brand/launch-preview.html` — standalone desktop/mobile responsive concept page.
- `src/` — rebranded Electron/Chromium desktop starter.

## Launch gating

No public distribution under the NIVQO name until a trademark search and rights review covers the UK, relevant international jurisdictions, classes 9 and 42, and similar marks. Domain ownership is not trademark clearance.
