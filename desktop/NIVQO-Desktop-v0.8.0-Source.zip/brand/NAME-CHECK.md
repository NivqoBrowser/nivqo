# NIVQO — preliminary name check

Date: 17 October 2026. **Working brand only; no trademark clearance has been completed.**

## Confirmed earlier use of exact name

- NIVQO s.r.o. is an existing Czech company, incorporated 3 June 2026 and renamed NIVQO s.r.o. on 11 September 2026. Its disclosed activities centre on trading, retail and related services rather than web browsers. Sources: https://www.podnikatel.cz/rejstrik/nivqo-s-r-o-29634661/ and https://fakturujzdarma.cz/firma/29634661-nivqo-s-r-o .

## Not confirmed

- UKIPO, EUIPO and WIPO trademark register clearance, including confusingly similar marks.
- Whether any relevant rights conflict with a Chromium-based browser in UK class 9 or related classes 38/42.
- Whether nivqo.com, nivqo.co.uk, nivqobrowser.com or matching handles are available to register.
- Advice from a qualified trade mark professional.

## Decision

Use **NIVQO** as an internal design and prototype name while preparing a formal rights search. Do not market or launch under the name until cleared. A company-name listing alone is not proof of infringement and absence of search results is not clearance.
