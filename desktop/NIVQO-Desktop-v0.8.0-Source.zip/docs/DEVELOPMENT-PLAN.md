# NIVQO Browser — Phase 2 implementation plan

**Prototype version:** 0.6.0 | **Date:** 17 October 2026 | **Status:** experimental desktop source prototype

## Product vision

A privacy-oriented, sleek Chromium browser built around **account-free continuity**. The primary differentiator is a one-time encrypted, consent-based peer connection between desktops, rather than requiring a browser account or syncing an entire profile to a vendor's cloud.

Do not promote the browser as anonymous or immune to tracking. NIVQO is a working brand, *not* cleared for commercial use; the name is in use by at least one foreign company and still requires a professional trademark search.

## Architecture

```
┌───────────────────────── LOCAL CHROME UI ───────────────────────────────┐
│ index.html + renderer.js + styles.css (offline file; restrictive CSP)  │
│ Tabs | Address | Spaces | Shield | Flow+Drop | Boost | Assist           │
└───────────────────────┬────────────────────────────────────────────────┘
                        │ context-isolated preload allowlist
┌───────────────────────▼────────────────────────────────────────────────┐
│ Main Electron process: trusted IPC sender enforcement                 │
│ - tab coordinator with isolated WebContentsView per active webpage    │
│ - session/partition manager per Space + in-memory private partitions  │
│ - request-level ad/tracker blocking + explicit permission denial      │
│ - local state persistence, read-only page extraction, tab sleeping    │
│ - FlowLink one-time X25519/HKDF/AES-256-GCM LAN pairing+transfers      │
└───────────┬────────────────────────┬──────────────────────────────────┘
            │                        │
    Chromium webpage views     LAN peer TCP connection
    sandboxed, no Node APIs     pairing code via private channel
    (cookies per partition)     encrypted + approval on receipt
```

**Storage:** app settings, bookmarks and optional history stored locally in a JSON file under the OS user-data directory. Each normal Space has its own Chromium persistent session partition. Private tabs use non-persistent partitions; pages and downloaded files can still leave traces outside the app. **No NIVQO account or relay service exists in v0.6.**

## Feature scope (v0.6 actual vs proposed)

| Feature | Working MVP | Constraints / future work |
|---|---|---|
| **Flow** | Manual one-time `nivqo-pair://` code; encrypted current-tab URL/title/scroll coordinate transfer; recipient approval | Desktop-to-desktop, same LAN; no QR pairing, background discovery, phone app, or internet relay; cookie/session continuity not supported |
| **Drop** | Send text or files up to 4 MiB over paired LAN; receiver approves; text copied to clipboard or file saved via file picker | No streaming, transfers resume, per-file hashes/signatures, or malware scanning |
| **Spaces** | Add/switch isolated named Spaces; separate cookies and caches and tagged bookmarks/history | No import/export, deletion UI, sharing, or sophisticated permissions per Space |
| **Shield** | Network-level tracker blocking with bundled small domain fallback + optional cached Ghostery filters; DNT/GPC; permissions default-denied | Not a complete anti-fingerprinting suite; no polished rules exception manager or phishing threat feed |
| **Boost** | Optional idle-tab sleep with configurable delay; Chromium background throttling | Experimental; discarding may lose forms, timers and media state; no benchmarks |
| **Assist** | User-triggered on-device extraction of headings and example article sentences; reading time estimate | Not a language model, not generative AI, summary quality varies |

## Development phases & acceptance criteria

### Stage A — Functional desktop prototype (v0.6, delivered as source)
**Scope:** browser chrome, tabs, session partitions, security defaults, encrypted local Flow+Drop, sleep, offline brief. **Check:** Node syntax; automated local loopback pairing tests; data-size and invalid-secret tests. **Not complete:** end-to-end UI navigation or packaged-OS QA.

### Stage B — Internal alpha (target v0.6)
- Launch and test on Windows 11 and modern macOS with latest supported Electron.
- Add Playwright/Electron UI smoke tests: navigation, tab lifecycle, context-menus, Spaces cookie isolation and private data deletion.
- Pair two physical PCs across Wi-Fi; validate timeout, firewall, multi-adapter selection, IPv6 and errors.
- Add a user-visible transfer log (no secret retention), optional transfer confirmation fingerprint, and secure pairing QR generator.
- Lock down CSP, content-origin checks, permission prompts, data migration and crash recovery.
**Exit:** documented tests pass on two OSes; critical crashes resolved.

### Stage C — Security & usability beta (target v0.6)
- Mandatory independent security review of Flow handshake, desktop IPC and data storage.
- Add transfer streaming, bounded concurrent connections, allowlisted mime types, malware scanning integration, and stronger URL checks.
- Add site permission controls, HTTPS warnings, better third-party cookie policy, user-friendly filter exceptions and Safe Browsing equivalent.
- Introduce credential handling through an audited platform vault (never invent own crypto-backed password manager).
- Accessibility, keyboard UX, privacy policy, reproducible build chain, crash logging **opt-in only**.
**Exit:** high-severity review findings resolved before public testing.

### Stage D — Multi-device continuity (target v0.7–0.8)
- iOS/Android companion feasibility assessment; OS constraints differ, especially iOS engine restrictions and background operation.
- QR pairing, locally trusted device identities with revocation; cross-network E2EE relay as strictly optional.
- Implement consent-based tab collections/bookmark sharing and smarter scroll restoration.
- Make session credentials and private-site context **non-transferable** by design.
**Exit:** login-free transfer succeeds across desktop/mobile and remains encrypted end-to-end under a documented threat model.

### Stage E — Real Chrome alternative (future major release)
- Consider full maintained Chromium fork for Web Store compatibility and true browser-native extension API support.
- Hardening: safe browsing, update signing, automatic Chromium security upgrades, permission manager, password manager, passkeys, download protection, profiles and migration tooling.
- Release signed installers with tested automatic patching and security-reporting process.
**Exit:** independently tested release candidate; privacy claims verified, not assumed.

## High-priority risks and decisions

1. **Electron vs full Chromium fork:** Electron is a pragmatic MVP framework but not a Chrome-feature-parity browser. Moving to a full fork is a substantial engineering/maintenance undertaking.
2. **Browser security operations:** Shipping a browser implies immediate patch response for Chromium CVEs, auto-updates and external reports; this cost exceeds the first build.
3. **Pairing UX:** No automatic LAN discovery yet; users manually copy the one-time pairing code. A full URL contains a secret; don't put it in screenshots, analytics or logs.
4. **Peer transfers:** LAN-only is simpler and keeps cloud infrastructure absent; cross-network continuity requires discovery/relay services and privacy-preserving design.
5. **Legal:** NIVQO name/domain/trademark have not received formal clearance. Preserve rebrandability.
6. **No unsupported promises:** Avoid 'no tracking', 'anonymous', 'Chrome compatible', or 'AI-powered summaries' as unconditional claims.

## Security checklist for every pull request

- Sandboxed webpage renderers; context isolation, Node disabled, strict protocol allowlist.
- Privileged IPC rejects all senders except the local chrome main frame.
- Renderer code never interprets untrusted webpage data as HTML (prefer `textContent`).
- No cookie/auth/history transfer via Flow; recipient must approve each payload.
- No plaintext telemetry or background browser-account synchronization.
- Filenames sanitised; limits enforced at sender and recipient.
- Keys ephemeral, paired data encrypted and authenticated; pairing window expires.
- Tests for invalid/oversized inputs, networking errors, rendering crashes, and data separation.
- Document supply-chain vulnerabilities; update supported dependencies frequently.

## Installation and internal test protocol

See root README.md and `docs/PAIRING-TEST.md`. Command-line checks: `npm run check` and `npm test` (tests do not need Electron). The UI requires `npm install` with network access to obtain dependencies. Installation and a live Chromium/Electron session **were not verified** by the automated build environment.
