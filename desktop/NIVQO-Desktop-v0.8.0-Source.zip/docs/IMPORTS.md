# Browser imports in NIVQO v0.7

Use **Import** in NIVQO to choose an export file, review its counts and a sample, then confirm. The preview expires after five minutes. Imports belong to the Space selected when the preview started. A new preview replaces the previous one.

## Bookmarks

Chrome, Brave, Vivaldi, Edge and Firefox can export bookmarks as an HTML file from their bookmark manager. NIVQO reads those links as text and never runs the imported HTML. A copied Chromium `Bookmarks` JSON file is also supported. Choose **All files** in the picker for an extensionless `Bookmarks` file.

Only HTTP and HTTPS links are imported. Links containing embedded username/password credentials are rejected. Bookmark names and addresses are preserved; source folders are flattened into the selected Space. Duplicate addresses in the same Space are skipped. The current desktop store supports a maximum of 1,000 bookmarks overall. Export files are limited to 5 MB and 10,000 source entries.

## Saved accounts and passwords

Export saved passwords as CSV from the source browser’s password manager, then choose **Passwords** in NIVQO. Chrome/Brave/Vivaldi/Edge exports with `name,url,username,password` columns are supported. Common variants such as `title`, `website`, `hostname`, `login_uri`, `login_username` and `login_password` are also recognized. Quoted commas, escaped quotes and line breaks in CSV values are supported. NIVQO preserves password characters exactly.

Review exposes only the site, account name and username. Importing saves each password encrypted by Electron `safeStorage` in `accounts-v1.json`, separately from browser state. On Windows this uses the operating-system user’s protected storage. Imports are refused when secure system encryption is unavailable, including a Linux plaintext fallback. No encryption key or password is sent to the browser renderer. The stored website, title, username and Space are metadata and are not encrypted in this version.

Accounts with the same address and username in the same Space are treated as duplicates: an import does **not** silently replace an existing password. Delete the existing saved account before importing a changed password. The vault supports up to 5,000 accounts overall. Use an account’s explicit copy action to copy its username or password; the app clears that clipboard text after 30 seconds if it is still unchanged. The operating system’s clipboard history or third-party clipboard managers may retain copied content. Copy and delete actions are restricted to the current Space. There is no automatic form filling in this release.

**Password CSV exports are plaintext.** Keep the file private and remove it once you have checked the import. NIVQO does not delete or modify your chosen source file. The in-memory preview is discarded on cancellation, replacement, expiry, completion or application shutdown; JavaScript cannot promise immediate erasure of every transient string from process memory.

Importing bookmarks or saved passwords does not import signed-in browser profiles, cookies, sessions, extensions or history. You need to sign in to websites again. NIVQO does not read another browser’s credential database, bypass its encryption, or transfer active sessions. Password vault files are tied to the operating-system account and are not a portable backup; keep the source browser available until you have verified your saved accounts.

## Developer API

`createImportService({app, dialog, safeStorage, clipboard, getStore, save, publish, getActiveSpace, getWindow})` is main-process-only. Attach methods only to trusted NIVQO chrome IPC, never to browsing tabs or remote pages. `getStore()` returns the current mutable store containing `bookmarks` and `spaces`; `save()` persists/schedules state saving and may return a promise.

- `await preview('bookmarks' | 'passwords')` opens a native picker and returns `{canceled:true}` or `{token,kind,source,spaceId,total,valid,duplicates,skipped,toImport,sample,expiresAt}`. `sample` contains at most eight `{title,url,username?}` objects; no passwords or ciphertext.
- `await commit(token)` consumes a one-use review token, rechecks duplicates/capacity/encryption, and returns `{kind,imported,duplicates,skipped,spaceId}`. The original Space must still exist. Confirmation uses the parsed snapshot, not a second reading of a source file that might have changed.
- `cancel(token)` discards that preview.
- `listAccounts()` returns `{id,title,url,username,spaceId,at}[]` across Spaces; render only the current Space.
- `copyAccount(id,'username' | 'password')` copies in the main process and returns `{copied:true,field,clearAfterSeconds:30}`.
- `deleteAccount(id)` removes an account from the active Space and returns `{deleted:true}`.
- `dispose()` clears previews and clears copied clipboard text if unchanged; call on shutdown.

All imported labels and addresses remain untrusted text. Render them using text nodes or HTML escaping. No method returns a password or encrypted-password payload to IPC callers. Preview tokens must not be exposed to browsing pages.
