# NIVQO Flow / Drop — desktop LAN test checklist

## Prerequisites

- Two desktops with NIVQO v0.7, connected to the **same private local network** (e.g., your home Wi-Fi).
- Launch `npm ci` and `npm start` on both; internet access is needed for the initial dependency installation, not for the actual LAN transfer.
- Allow NIVQO through the OS firewall **only on trusted/private networks** when prompted. Do not expose pairing ports through your router or to the public internet.

## Test account-free handoff

1. Open the **Flow** panel on computer A.
2. Select **Create pairing QR**, then **Copy code**. It is valid for about **two minutes** and must be treated as a temporary password.
3. Privately move that code to computer B, paste it into the Flow panel, and select **Pair with device**. There is **no NIVQO login** at any point.
4. On computer A, open an ordinary HTTPS page. Click **Send current tab**.
5. On computer B, open Flow and find **Incoming transfers**. Click **Accept** to open the page. The scroll position may restore approximately; site logins do **not** transfer.
6. Use **NIVQO Drop** to send a short sentence. Accept it on B; it should be copied into the B clipboard.
7. Send a small non-sensitive file (under 4 MiB). Accept and choose a save location on B.
8. Repeat in reverse direction and test **Decline**. Disconnect and confirm the pairing code no longer works.

## Expected limitations

- This is not Wi-Fi Direct or Apple's Handoff: both apps must be open and the host must be reachable via TCP on the LAN.
- It picks the first suitable LAN IPv4 address; VPNs or multiple adapters may select the wrong one. No IPv6 or public-internet relay yet.
- Pairing secret is never saved; after disconnect, a new pairing code must be generated.
- Received transfers expire after ten minutes; receiving a file still requires manually accepting/saving it.
- Flow does **not** clone browsing sessions, logged-in state, form inputs, passwords or private tabs.
- The handshake design and app haven't undergone third-party security auditing. Test with non-sensitive files and sites.

## Troubleshooting

- Cannot connect: check same subnet, firewall profile, VPN/network isolation and whether the pairing code has expired.
- Wrong code: generate a fresh code on computer A. Do not post codes publicly.
- File rejected: limit is 4 MiB for this prototype. A larger-file streaming transport is a later goal.
- Tab isn't logged in after handoff: expected, the receiving browser has its own cookies/Space.


## QR and iPhone validation

Decode a generated desktop QR as a PNG and confirm it matches the manual code. Reject non-pairing QR images and expired codes. On a physical iPhone, build/sign the native project first, then test Scan desktop QR, Local Network permission, pairing, tabs, text, files, acceptance/decline and background disconnects. These physical iPhone tests have not been run on Windows. Desktop QR and loopback transfer tests are included in npm test.
