# Installing and distributing NIVQO updates

NIVQO v0.7 uses **manual Windows installers**, as requested. This release has no live update server, background update check, silent download, or automatic installer execution. The included workflow builds files for review; it does not publish a release.

## Upgrade an existing Windows installation

1. Close every NIVQO window and make sure NIVQO has exited before updating.
2. As a precaution, copy the existing profile folder to a separate backup location while the app is closed. The app can show its profile location; the usual Windows location is `%APPDATA%\Nivqo Browser`. Use the actual profile path shown by the app if it differs.
3. Download the new `NIVQO-Browser-0.7.0-win-x64.exe` from the maintainer's chosen release location. Compare its SHA-256 and byte count with the supplied release-verification file.
4. Run it under the **same Windows account**, retaining the existing installation location. Do not uninstall the previous version or delete the profile as part of the upgrade.
5. Open NIVQO and confirm the version, Spaces, bookmarks and preferences. Check an existing browser session before deleting the profile backup.

The build preserves the existing application ID (`dev.nivqo.browseralpha`), application name (`Nivqo Browser`), and per-user installer configuration. Those identifiers and the user-data path must remain stable in later releases. Local browser data is kept separately from the installed program; this upgrade path is intended to preserve it. A complete v0.6-to-v0.7 installation/profile migration must still be tested on Windows before wider distribution. A source ZIP is developer source, not an installed application.

Windows can display a publisher/SmartScreen prompt for an unsigned build. Check the actual signature report for each release; neither a successful build nor a matching SHA-256 means the program is signed. Do not advertise it as signed unless the final installer verifies as signed by the expected publisher.

## Build the next release locally

Run these commands in the desktop project folder with Node.js 22 and npm installed:

```powershell
# Example next release. Commit the package and lockfile changes with the code.
npm version 0.7.1 --no-git-tag-version
npm ci
npm run verify
npm run dist:win -- --publish never
```

The installer is written to `dist/NIVQO-Browser-<version>-win-x64.exe`. Keep the existing `build.appId`, `productName`, `app.setName`, installer mode, and profile path unchanged. Release versions must increase; a rollback is a separately tested manual procedure and must account for profile-format compatibility.

Create a source ZIP containing the same committed code, the package lockfile, build resources, documentation, and tests. Exclude dependencies, build outputs, credentials, browser profiles, and exported passwords. For a clean Git repository with the release committed:

```powershell
$releaseVersion = (Get-Content -Raw package.json | ConvertFrom-Json).version
git archive --format=zip "--output=dist/NIVQO-Desktop-$releaseVersion-Source.zip" HEAD
node scripts/release-manifest.js --installer "dist/NIVQO-Browser-$releaseVersion-win-x64.exe" --source "dist/NIVQO-Desktop-$releaseVersion-Source.zip" --out dist
Get-AuthenticodeSignature -LiteralPath "dist/NIVQO-Browser-$releaseVersion-win-x64.exe"
```

`release-manifest.js` calculates the exact byte count and SHA-256 of the files on disk and checks that the installer filename matches the package version and Windows x64 target. It writes `release-verification.json` and `SHA256SUMS.txt`. These files describe artifacts; they are **not** an online updater manifest and do not authenticate the publisher. Generate them after signing, because signing changes the installer bytes. The script rejects an altered application ID, empty files, files changed while hashing, and mismatched installer versions.

## Optional GitHub build workflow

The source includes `.github/workflows/build-installers.yml`. GitHub only discovers workflows at the **repository root**. If the repository contains `desktop/` and `ios/`, place this workflow at the repository's `.github/workflows/build-installers.yml`; it detects `desktop/package.json`. If the desktop project itself is the repository root, use the included location unchanged.

The workflow can be started manually or by pushing a version tag such as `v0.7.1`. It checks the tag against `package.json`, installs locked dependencies, runs checks/tests, builds the Windows x64 installer, creates a committed-source ZIP, records the actual Authenticode status, and saves an artifact bundle with checksums. Its repository permission is read-only. It has no release-publishing step and no live hosting configuration. The generated source ZIP represents committed source; commit all desired changes before triggering the workflow.

For signing, configure the repository secrets `WINDOWS_CSC_LINK` and `WINDOWS_CSC_KEY_PASSWORD` with signing material supported by electron-builder. The workflow passes these to `CSC_LINK` and `CSC_KEY_PASSWORD`. Without configured signing credentials, the output must be described as unsigned unless the signature report says otherwise. If signing is configured but the resulting installer signature is not valid, the build fails. A managed hardware-backed signing service may require its own provider configuration; do not put private keys or passwords in the repository. See [electron-builder's Windows signing guide](https://www.electron.build/docs/features/code-signing/code-signing-win/) and [GitHub Actions guide](https://www.electron.build/docs/github-actions/).

## Share a reviewed release

1. Test the new installer in a fresh Windows profile and over the previous NIVQO version. Confirm browsing, saved data, imports, and Flow + Drop on two devices. Record what was actually tested.
2. Inspect the signature status and publisher. Keep the installer, source ZIP, verification JSON and checksum file together.
3. Upload them to the release host you choose, for example GitHub Releases or your own HTTPS download page. Use a stable downloadable file URL, not a temporary chat sandbox link or expiring build artifact link.
4. Open the published link in a separate browser session, download the actual file, and compare its size/hash with the release-verification file. Publish notes identifying the version, changes, platform, signing status and known limitations.
5. Tell users to close NIVQO and run the new installer under their existing Windows account.

No public repository, download host, release URL, signing identity, or automatic update service is configured by this project. A GitHub workflow artifact is for maintainer review and can expire; it is not the permanent user download link. Hosting or publishing can be added after a destination is selected.

## Verify a download on Windows

```powershell
Get-Item -LiteralPath '.\NIVQO-Browser-0.7.0-win-x64.exe' | Select-Object Name, Length
Get-FileHash -Algorithm SHA256 -LiteralPath '.\NIVQO-Browser-0.7.0-win-x64.exe'
Get-AuthenticodeSignature -LiteralPath '.\NIVQO-Browser-0.7.0-win-x64.exe' | Select-Object Status, SignerCertificate
```

Compare `Length` and `Hash` to the same release's verification file from the trusted release location. Hashes detect changed bytes; their trust depends on where the expected values came from.

## iPhone builds

The native iPhone project is separate from the Windows installer. Updating it means building and signing a new iOS app with the same bundle identifier and installing through the chosen Apple-supported development/sideloading route. A Windows `.exe` cannot install on an iPhone. See the iPhone project's own build and signing instructions; the Windows workflow does not compile or sign iOS.
