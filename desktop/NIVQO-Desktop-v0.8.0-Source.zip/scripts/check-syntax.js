'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
for (const folder of ['src', 'scripts']) for (const file of fs.readdirSync(folder).filter(x => x.endsWith('.js'))) {
 const result = spawnSync(process.execPath, ['--check', path.join(folder, file)], { stdio: 'inherit' });
 if (result.status !== 0) process.exit(result.status || 1);
}
