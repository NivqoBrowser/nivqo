'use strict';

// This describes local release files. It neither publishes them nor configures
// an update feed, and a checksum is not a publisher signature.
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');

async function describeFile(filePath, kind) {
  const resolved = path.resolve(filePath);
  const before = await fsp.stat(resolved);
  if (!before.isFile() || before.size === 0) throw new Error(`Not a nonempty file: ${resolved}`);
  const hash = createHash('sha256');
  let size = 0;
  for await (const chunk of fs.createReadStream(resolved)) {
    hash.update(chunk);
    size += chunk.length;
  }
  const after = await fsp.stat(resolved);
  if (before.size !== size || after.size !== size || before.mtimeMs !== after.mtimeMs || before.ctimeMs !== after.ctimeMs) {
    throw new Error(`File changed during verification: ${resolved}`);
  }
  const file = path.basename(resolved);
  if (/[\r\n]/.test(file)) throw new Error('Release filenames must not contain line breaks.');
  return { kind, file, bytes: size, sha256: hash.digest('hex') };
}

async function createReleaseManifest({ installer, source, outDir, packageFile = path.join(__dirname, '..', 'package.json') }) {
  if (!installer || !source || !outDir) throw new Error('Provide --installer, --source, and --out.');
  const pkg = JSON.parse(await fsp.readFile(packageFile, 'utf8'));
  if (!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(pkg.version)) {
    throw new Error('A release version must be a stable major.minor.patch version in package.json.');
  }
  if (pkg.build?.appId !== 'dev.nivqo.browseralpha') throw new Error('The existing appId must be preserved for upgrades.');
  if (path.basename(installer) !== `NIVQO-Browser-${pkg.version}-win-x64.exe`) {
    throw new Error('Installer filename does not match the package version and Windows x64 target.');
  }
  if (path.extname(source).toLowerCase() !== '.zip') throw new Error('The source artifact must be a ZIP.');
  const artifacts = await Promise.all([
    describeFile(installer, 'windows-x64-installer'),
    describeFile(source, 'source-zip')
  ]);
  const manifest = {
    schemaVersion: 1,
    product: 'NIVQO Browser Alpha',
    version: pkg.version,
    appId: pkg.build.appId,
    createdAt: new Date().toISOString(),
    distribution: 'manual-installer',
    signatureVerification: 'Not performed by this script. Check signing-report.json or Get-AuthenticodeSignature separately.',
    artifacts
  };
  const destination = path.resolve(outDir);
  await fsp.mkdir(destination, { recursive: true });
  await fsp.writeFile(path.join(destination, 'release-verification.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');
  await fsp.writeFile(path.join(destination, 'SHA256SUMS.txt'), artifacts.map(item => `${item.sha256} *${item.file}`).join('\r\n') + '\r\n', 'utf8');
  return manifest;
}

function parseArguments(args) {
  const result = {};
  const names = { '--installer': 'installer', '--source': 'source', '--out': 'outDir' };
  for (let i = 0; i < args.length; i += 2) {
    const name = names[args[i]];
    if (!name || !args[i + 1] || args[i + 1].startsWith('--') || result[name]) {
      throw new Error('Usage: node scripts/release-manifest.js --installer <exe> --source <zip> --out <directory>');
    }
    result[name] = args[i + 1];
  }
  return result;
}

if (require.main === module) {
  Promise.resolve().then(() => createReleaseManifest(parseArguments(process.argv.slice(2))))
    .then(manifest => process.stdout.write(JSON.stringify(manifest, null, 2) + '\n'))
    .catch(error => { process.stderr.write(`Release verification failed: ${error.message}\n`); process.exitCode = 1; });
}

module.exports = { createReleaseManifest, describeFile, parseArguments };
