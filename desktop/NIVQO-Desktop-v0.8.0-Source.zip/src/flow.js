'use strict';
/**
 * NIVQO Flow MVP: manually paired LAN transport. Zero accounts, zero relay.
 * Pairing string has a 256-bit randomly-generated pre-shared secret; an
 * ephemeral X25519 ECDH handshake is bound to that secret using HKDF/HMAC.
 * Post-handshake frames use authenticated AES-256-GCM, ordered counters and
 * explicit frame limits. No cookies, credentials or history are transferred.
 * Experimental transport; NOT independently audited.
 */
const net = require('node:net');
const os = require('node:os');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const MAX_FRAME = 8 * 1024 * 1024;
const FILE_LIMIT = 4 * 1024 * 1024;
const HANDSHAKE_TIMEOUT = 15000;
const PAIR_WINDOW_MS = 2 * 60 * 1000;
const ALLOWED = new Set(['flow-tab', 'drop-text', 'drop-file']);
const b64 = bytes => Buffer.from(bytes).toString('base64url');
function sameMac(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function makeMac(key, value) { return crypto.createHmac('sha256', key).update(value).digest('base64url'); }
function localIP() {
  for (const set of Object.values(os.networkInterfaces())) {
    for (const item of set || []) {
      if (item.family === 'IPv4' && !item.internal && !item.address.startsWith('169.254.')) return item.address;
    }
  }
  return '127.0.0.1';
}
function parsePairCode(value) {
  const input = String(value || '').trim();
  if (!/^nivqo-pair:\/\/(?:[0-9]{1,3}\.){3}[0-9]{1,3}:[0-9]{1,5}\/[A-Za-z0-9_-]{43}$/.test(input)) throw new Error('Invalid pairing code');
  const uri = new URL(input);
  if (uri.protocol !== 'nivqo-pair:' || !uri.hostname || !/^\d+$/.test(uri.port)) throw new Error('Invalid pairing code');
  const port = Number(uri.port);
  const secret = uri.pathname.slice(1);
  if (port < 1 || port > 65535 || !/^[A-Za-z0-9_-]{43}$/.test(secret)) throw new Error('Invalid pairing code');
  // Only a literal private LAN IPv4 address or loopback is allowed for MVP.
  const parts = uri.hostname.split('.').map(Number);
  const validIPv4 = parts.length === 4 && parts.every(n => Number.isInteger(n) && n >= 0 && n <= 255) && parts.join('.') === uri.hostname;
  const priv = validIPv4 && (parts[0] === 10 || parts[0] === 127 || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 192 && parts[1] === 168));
  if (!priv) throw new Error('Pairing is limited to private LAN IPv4 addresses');
  const decoded = Buffer.from(secret, 'base64url');
  if (decoded.length !== 32 || decoded.toString('base64url') !== secret) throw new Error('Invalid pairing secret');
  return { host: uri.hostname, port, secret: decoded };
}
class FlowLink extends EventEmitter {
  constructor() {
    super(); this.server = null; this.socket = null; this.secret = null;
    this.connected = false; this.pairCode = ''; this.status = 'disconnected'; this.peerLabel = '';
    this.handshakeTimer = null; this.hostTimer = null; this.sendSeq = 0; this.recvSeq = 0;
  }
  update(status, extra = {}) { this.status = status; this.emit('status', { status, pairCode: this.pairCode, connected: this.connected, ...extra }); }
  async host({ bindHost = '0.0.0.0', advertiseHost = localIP() } = {}) {
    this.disconnect();
    this.secret = crypto.randomBytes(32);
    this.server = net.createServer(socket => {
      if (this.socket) return socket.destroy();
      this.attach(socket, true);
    });
    try {
      await new Promise((resolve, reject) => {
        this.server.once('error', reject);
        this.server.listen(0, bindHost, () => { this.server.removeListener('error', reject); resolve(); });
      });
    } catch (err) { this.disconnect(); throw err; }
    const port = this.server.address().port;
    this.pairCode = `nivqo-pair://${advertiseHost}:${port}/${b64(this.secret)}`;
    this.update('awaiting-pair');
    this.server.on('error', err => this.emit('error', err));
    this.hostTimer = setTimeout(() => {
      if (!this.connected && this.server) this.disconnect();
    }, PAIR_WINDOW_MS);
    this.hostTimer.unref?.();
    return this.pairCode;
  }
  async join(code) {
    this.disconnect();
    const { host, port, secret } = parsePairCode(code);
    this.secret = secret;
    const socket = net.createConnection({ host, port });
    this.attach(socket, false);
    return new Promise((resolve, reject) => {
      const success = () => { cleanup(); resolve(true); };
      const fail = err => { cleanup(); reject(err instanceof Error ? err : new Error('Pairing connection closed')); };
      const gone = () => fail(new Error('Pairing connection closed before authentication'));
      const cleanup = () => { this.off('connected', success); this.off('error', fail); this.off('disconnected', gone); };
      this.on('connected', success); this.on('error', fail); this.on('disconnected', gone);
    });
  }
  attach(socket, isHost) {
    this.socket = socket; this.connected = false;
    this.sendSeq = 0; this.recvSeq = 0;
    const keys = crypto.generateKeyPairSync('x25519');
    const myPub = keys.publicKey.export({ format: 'der', type: 'spki' });
    let remotePub = null, serverPub = null, clientPub = null;
    let txKey = null, rxKey = null;
    let stage = isHost ? 'wait-hello' : 'wait-challenge';
    let incoming = Buffer.alloc(0);
    const writeFrame = obj => {
      if (socket.destroyed) return;
      const bytes = Buffer.from(JSON.stringify(obj));
      if (bytes.length > MAX_FRAME) throw new Error('Frame too large');
      const header = Buffer.alloc(4); header.writeUInt32BE(bytes.length);
      socket.write(Buffer.concat([header, bytes]));
    };
    const derive = () => {
      const shared = crypto.diffieHellman({ privateKey: keys.privateKey, publicKey: crypto.createPublicKey({ key: remotePub, format: 'der', type: 'spki' }) });
      const transcript = Buffer.concat([clientPub, serverPub]);
      const material = Buffer.from(crypto.hkdfSync('sha256', shared, this.secret, transcript, 96));
      const proofKey = material.subarray(0,32);
      txKey = isHost ? material.subarray(32,64) : material.subarray(64,96);
      rxKey = isHost ? material.subarray(64,96) : material.subarray(32,64);
      return proofKey;
    };
    let proofKey = null;
    const handshakeDone = () => {
      stage = 'secure'; this.connected = true; this.pairCode = ''; this.secret = null;
      if (this.server) { this.server.close(); this.server = null; }
      clearTimeout(this.handshakeTimer); clearTimeout(this.hostTimer); this.peerLabel = socket.remoteAddress || 'LAN device';
      this.update('connected'); this.emit('connected');
    };
    const fail = err => { this.emit('error', err instanceof Error ? err : new Error(String(err))); socket.destroy(); };
    const handle = item => {
      if (stage === 'wait-hello') {
        if (item.kind !== 'hello' || typeof item.pub !== 'string') throw new Error('Unexpected pairing handshake');
        remotePub = Buffer.from(item.pub, 'base64url'); clientPub = remotePub; serverPub = myPub;
        proofKey = derive();
        writeFrame({ kind: 'challenge', pub: b64(myPub), proof: makeMac(proofKey, Buffer.concat([clientPub,serverPub,Buffer.from('server')])) });
        stage = 'wait-proof'; return;
      }
      if (stage === 'wait-challenge') {
        if (item.kind !== 'challenge' || typeof item.pub !== 'string' || typeof item.proof !== 'string') throw new Error('Unexpected pairing response');
        remotePub = Buffer.from(item.pub, 'base64url'); clientPub = myPub; serverPub = remotePub;
        proofKey = derive();
        const expected = makeMac(proofKey, Buffer.concat([clientPub,serverPub,Buffer.from('server')]));
        if (!sameMac(item.proof, expected)) throw new Error('Pairing authentication failed');
        writeFrame({ kind: 'proof', proof: makeMac(proofKey, Buffer.concat([clientPub,serverPub,Buffer.from('client')])) });
        handshakeDone(); return;
      }
      if (stage === 'wait-proof') {
        if (item.kind !== 'proof' || typeof item.proof !== 'string') throw new Error('Unexpected pairing confirmation');
        const expected = makeMac(proofKey, Buffer.concat([clientPub,serverPub,Buffer.from('client')]));
        if (!sameMac(item.proof, expected)) throw new Error('Pairing authentication failed');
        handshakeDone(); return;
      }
      if (stage === 'secure') {
        if (item.kind !== 'sealed' || !Number.isSafeInteger(item.seq) || item.seq !== this.recvSeq + 1) throw new Error('Replay or invalid message');
        const iv = Buffer.from(item.iv || '', 'base64url');
        const cipher = Buffer.from(item.data || '', 'base64url');
        const tag = Buffer.from(item.tag || '', 'base64url');
        if (iv.length !== 12 || tag.length !== 16) throw new Error('Malformed encrypted message');
        const decipher = crypto.createDecipheriv('aes-256-gcm', rxKey, iv);
        decipher.setAAD(Buffer.from(String(item.seq)));
        decipher.setAuthTag(tag);
        const obj = JSON.parse(Buffer.concat([decipher.update(cipher), decipher.final()]).toString());
        if (!obj || !ALLOWED.has(obj.type)) throw new Error('Unsupported payload');
        this.recvSeq = item.seq;
        this.emit('message', obj);
      }
    };
    socket.on('connect', () => {
      if (!isHost) writeFrame({ kind:'hello', pub: b64(myPub) });
    });
    socket.on('data', chunk => {
      if (socket.destroyed || this.socket !== socket) return;
      if (incoming.length + chunk.length > MAX_FRAME + 65540) { fail(new Error('Incoming frame buffer exceeded')); return; }
      incoming = Buffer.concat([incoming,chunk]);
      try {
        while (incoming.length >= 4) {
          const n = incoming.readUInt32BE(0);
          if (!n || n > (stage === 'secure' ? MAX_FRAME : 4096)) throw new Error('Invalid frame length');
          if (incoming.length < n + 4) break;
          const raw = incoming.subarray(4, n+4);
          incoming = incoming.subarray(n+4);
          handle(JSON.parse(raw.toString()));
        }
      } catch(err) { fail(err); }
    });
    socket.on('error', err => this.emit('error', err));
    socket.on('close', () => {
      if (this.socket === socket) {
        clearTimeout(this.handshakeTimer); clearTimeout(this.hostTimer);
        if (this.server) { this.server.close(); this.server = null; }
        this.secret = null; this._writeFrame = null; this._getTx = null;
        this.socket = null; this.connected = false;
        // Do not leave the old pairing code active after a disconnect.
        this.pairCode = ''; this.update('disconnected'); this.emit('disconnected');
      }
    });
    this._writeFrame = writeFrame;
    this._getTx = () => txKey;
    this.handshakeTimer = setTimeout(() => { if (!this.connected) socket.destroy(new Error('Pairing timed out')); }, HANDSHAKE_TIMEOUT);
    this.handshakeTimer.unref?.();
  }
  send(type, data) {
    if (!this.connected || !this.socket || !this._getTx?.()) throw new Error('No paired device connected');
    if (!ALLOWED.has(type)) throw new Error('Unsupported transfer type');
    if (type === 'flow-tab' && (!data || !/^https?:\/\//.test(data.url || '') || String(data.url).length > 4096)) throw new Error('Unsafe tab URL');
    if (type === 'drop-text' && (typeof data?.text !== 'string' || data.text.length > 100000)) throw new Error('Text too large');
    if (type === 'drop-file' && (typeof data?.data !== 'string' || Buffer.byteLength(data.data, 'base64') > FILE_LIMIT)) throw new Error('File exceeds 4 MB prototype limit');
    if (this.sendSeq >= Number.MAX_SAFE_INTEGER) throw new Error('Session counter exhausted; pair again');
    const plain = Buffer.from(JSON.stringify({ type, data }));
    if (plain.length > MAX_FRAME - 1000) throw new Error('Payload too large');
    const seq = ++this.sendSeq;
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', this._getTx(), iv);
    cipher.setAAD(Buffer.from(String(seq)));
    const enc = Buffer.concat([cipher.update(plain),cipher.final()]);
    this._writeFrame({ kind:'sealed', seq, iv:b64(iv), data:b64(enc), tag:b64(cipher.getAuthTag()) });
    return true;
  }
  disconnect() {
    clearTimeout(this.handshakeTimer); clearTimeout(this.hostTimer);
    if (this.socket) { this.socket.destroy(); this.socket = null; }
    if (this.server) { this.server.close(); this.server = null; }
    this.secret = null; this.pairCode = ''; this.connected = false;
    this._writeFrame = null; this._getTx = null;
    this.update('disconnected');
  }
}
module.exports = { FlowLink, parsePairCode, FILE_LIMIT };
