'use strict';

// Read browser exports only. Never open another browser's databases or execute HTML.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_FILE_BYTES = 5 * 1024 * 1024;
const MAX_RECORDS = 10000;
const MAX_BOOKMARKS = 1000; // Matches the existing state.json loader.
const MAX_ACCOUNTS = 5000;
const PREVIEW_TTL_MS = 5 * 60 * 1000;
const CLIPBOARD_TTL_MS = 30 * 1000;

function webUrl(value) {
  if (typeof value !== 'string' || value.length > 8192 || /[\u0000-\u001f\u007f]/.test(value)) return null;
  try {
    const url = new URL(value.trim());
    return ['https:', 'http:'].includes(url.protocol) && url.hostname && !url.username && !url.password ? url.href : null;
  } catch { return null; }
}

function label(value, fallback = '') {
  return String(value || fallback).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 500);
}

function decodeEntities(text) {
  const named = { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' };
  return text.replace(/&(#x[0-9a-f]+|#\d+|amp|quot|apos|lt|gt|nbsp);/gi, (match, entity) => {
    if (entity[0] !== '#') return named[entity.toLowerCase()] || match;
    const number = entity[1].toLowerCase() === 'x' ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
    return number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff) ? String.fromCodePoint(number) : '\ufffd';
  });
}

function assertRecordCount(count) {
  if (count > MAX_RECORDS) throw new Error('This export has more than 10,000 entries. Export a smaller selection.');
}

function parseBookmarks(source) {
  const text = String(source).replace(/^\ufeff/, '');
  const records = [];
  let total = 0;
  const add = (urlValue, title) => {
    assertRecordCount(++total);
    const url = webUrl(urlValue);
    if (url) records.push({ url, title: label(title, new URL(url).hostname) });
  };
  if (text.trimStart().startsWith('{')) {
    let json;
    try { json = JSON.parse(text); } catch { throw new Error('The bookmarks JSON is not valid. Choose a Chromium Bookmarks file or an HTML export.'); }
    if (!json || !json.roots || typeof json.roots !== 'object' || Array.isArray(json.roots)) {
      throw new Error('This JSON is not a Chromium Bookmarks file. Use your browser’s HTML bookmark export.');
    }
    const stack = Object.values(json.roots).reverse();
    let visited = 0;
    while (stack.length) {
      if (++visited > 50000) throw new Error('This bookmarks file contains too many folders or entries.');
      const item = stack.pop();
      if (!item || typeof item !== 'object') continue;
      if (item.type === 'url' || typeof item.url === 'string') add(item.url, item.name);
      if (Array.isArray(item.children)) {
        if (stack.length + item.children.length > 50000) throw new Error('This bookmarks file contains too many folders or entries.');
        for (let i = item.children.length - 1; i >= 0; i--) stack.push(item.children[i]);
      }
    }
  } else {
    // A text-only extractor; no DOM, renderer navigation or script evaluation.
    const html = text.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style|template)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, '');
    const anchors = /<a\b((?:[^>"']|"[^"]*"|'[^']*')*)>([\s\S]*?)<\/a\s*>/gi;
    let match;
    while ((match = anchors.exec(html))) {
      const attributes = /(?:^|\s)([^\s=]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g;
      let attr, href = null;
      while ((attr = attributes.exec(match[1]))) {
        if (attr[1].toLowerCase() === 'href') { href = decodeEntities(attr[2] ?? attr[3] ?? attr[4]); break; }
      }
      add(href, decodeEntities(match[2].replace(/<[^>]*>/g, '')));
    }
    if (!total) throw new Error('No bookmarks found. Choose an HTML bookmarks export or a Chromium Bookmarks JSON file.');
  }
  return { records, total, skipped: total - records.length };
}

function csvRows(source) {
  const text = String(source).replace(/^\ufeff/, '');
  const rows = [];
  let row = [], field = '', quoted = false, closed = false;
  const pushField = () => { row.push(field); field = ''; closed = false; };
  const pushRow = () => {
    pushField();
    if (row.some(value => value !== '')) rows.push(row);
    row = [];
    if (rows.length > MAX_RECORDS + 1) throw new Error('This password export has more than 10,000 entries. Export a smaller selection.');
  };
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (char === '"') { quoted = false; closed = true; }
      else field += char;
    } else if (char === ',') pushField();
    else if (char === '\n' || char === '\r') { if (char === '\r' && text[i + 1] === '\n') i++; pushRow(); }
    else if (char === '"' && field === '' && !closed) quoted = true;
    else if (closed || char === '"') throw new Error('Malformed password CSV: a quoted field is not correctly escaped.');
    else field += char;
    if (field.length > 32768 || row.length > 100) throw new Error('The CSV contains an oversized field or too many columns.');
  }
  if (quoted) throw new Error('Malformed password CSV: an opening quote has no closing quote.');
  if (field !== '' || row.length || closed) pushRow();
  return rows;
}

function parsePasswords(source) {
  const rows = csvRows(source);
  if (!rows.length) throw new Error('The password CSV is empty.');
  const headers = rows.shift().map(value => value.toLowerCase().trim().replace(/[\s_-]/g, ''));
  const index = (...names) => { for (const name of names) { const i = headers.indexOf(name); if (i >= 0) return i; } return -1; };
  const urlIndex = index('url', 'website', 'origin', 'hostname', 'loginuri', 'loginurl');
  const usernameIndex = index('username', 'loginusername', 'login', 'email', 'user');
  const passwordIndex = index('password', 'loginpassword', 'pass');
  const titleIndex = index('name', 'title', 'account');
  if ([urlIndex, usernameIndex, passwordIndex].includes(-1)) throw new Error('The CSV needs URL, username and password columns. Use your browser’s saved-password export.');
  const records = [];
  for (const row of rows) {
    const url = webUrl(row[urlIndex]);
    const username = row[usernameIndex];
    const password = row[passwordIndex];
    if (!url || typeof username !== 'string' || username.length > 1024 || /[\u0000-\u001f\u007f]/.test(username)
        || typeof password !== 'string' || !password || password.length > 16384 || password.includes('\0')) continue;
    records.push({ url, title: label(row[titleIndex], new URL(url).hostname), username, password });
  }
  return { records, total: rows.length, skipped: rows.length - records.length };
}

function readLimited(filename, limit) {
  const fd = fs.openSync(filename, 'r');
  try {
    const stat = fs.fstatSync(fd);
    if (!stat.isFile() || stat.size > limit) throw new Error(`Choose a regular export file smaller than ${Math.round(limit / 1024 / 1024)} MB.`);
    // Bound the actual read too, including files that grow after the size check.
    const bytes = Buffer.alloc(Math.min(stat.size + 1, limit + 1));
    let offset = 0, read;
    while (offset < bytes.length && (read = fs.readSync(fd, bytes, offset, bytes.length - offset, null))) offset += read;
    if (offset > limit || offset > stat.size) throw new Error('The export changed while reading. Choose the completed export file again.');
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(0, offset)); }
    catch { throw new Error('The export must use UTF-8 text encoding. Export the file again from your browser.'); }
  } finally { fs.closeSync(fd); }
}

function accountKey(record) { return JSON.stringify([record.spaceId, record.url, record.username]); }
function bookmarkKey(record) { return JSON.stringify([record.spaceId, webUrl(record.url) || record.url]); }

function createImportService({ app, dialog, safeStorage, clipboard, getStore, save, publish, getActiveSpace, getWindow,
  now = Date.now, setTimer = setTimeout, clearTimer = clearTimeout }) {
  const vaultFile = path.join(app.getPath('userData'), 'accounts-v1.json');
  let pending = null, clipboardTimer = null, copiedText = null;

  function requireEncryption() {
    if (!safeStorage || !safeStorage.isEncryptionAvailable()
        || (typeof safeStorage.getSelectedStorageBackend === 'function' && safeStorage.getSelectedStorageBackend() === 'basic_text')) {
      throw new Error('Secure system encryption is unavailable. Password imports and copying are disabled until the operating-system keychain is available.');
    }
  }
  function readVault() {
    if (!fs.existsSync(vaultFile)) return { version: 1, accounts: [] };
    let vault;
    try { vault = JSON.parse(readLimited(vaultFile, 128 * 1024 * 1024)); }
    catch { throw new Error('The saved-account vault could not be read. Your existing vault has not been changed.'); }
    if (!vault || vault.version !== 1 || !Array.isArray(vault.accounts) || vault.accounts.length > MAX_ACCOUNTS
      || vault.accounts.some(record => !record || typeof record.id !== 'string' || !webUrl(record.url)
        || typeof record.spaceId !== 'string' || typeof record.username !== 'string' || typeof record.title !== 'string'
        || typeof record.encryptedPassword !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(record.encryptedPassword))) {
      throw new Error('The saved-account vault has an unsupported format. Your existing vault has not been changed.');
    }
    return vault;
  }
  function writeVault(vault) {
    fs.mkdirSync(path.dirname(vaultFile), { recursive: true });
    const temporary = `${vaultFile}.${crypto.randomUUID()}.tmp`;
    try {
      fs.writeFileSync(temporary, JSON.stringify(vault), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
      fs.renameSync(temporary, vaultFile);
    } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
  }
  function clearPreview() {
    if (!pending) return;
    clearTimer(pending.timer);
    for (const record of pending.records) if ('password' in record) record.password = '';
    pending = null;
  }
  function partition(records, kind, spaceId) {
    const existing = kind === 'bookmarks' ? getStore().bookmarks : readVault().accounts;
    const key = kind === 'bookmarks' ? bookmarkKey : accountKey;
    const known = new Set(existing.map(key));
    const unique = [];
    let duplicates = 0;
    for (const record of records) {
      const item = { ...record, spaceId };
      const identity = key(item);
      if (known.has(identity)) duplicates++;
      else { known.add(identity); unique.push(item); }
    }
    const capacity = (kind === 'bookmarks' ? MAX_BOOKMARKS : MAX_ACCOUNTS) - existing.length;
    if (unique.length > capacity) throw new Error(`This import exceeds the ${kind === 'bookmarks' ? '1,000 bookmark' : '5,000 saved account'} limit. Export a smaller selection.`);
    return { unique, duplicates };
  }

  async function preview(kind) {
    if (!['bookmarks', 'passwords'].includes(kind)) throw new Error('Choose bookmarks or passwords to import.');
    clearPreview();
    if (kind === 'passwords') requireEncryption();
    const spaceId = getActiveSpace();
    const options = {
      title: kind === 'bookmarks' ? 'Choose an exported bookmarks file' : 'Choose an exported password CSV',
      properties: ['openFile'],
      filters: kind === 'bookmarks' ? [{ name: 'Bookmarks HTML or JSON', extensions: ['html', 'htm', 'json'] }, { name: 'All files', extensions: ['*'] }]
        : [{ name: 'Password CSV', extensions: ['csv'] }]
    };
    const window = getWindow && getWindow();
    const selected = window ? await dialog.showOpenDialog(window, options) : await dialog.showOpenDialog(options);
    if (selected.canceled || !selected.filePaths || !selected.filePaths[0]) return { canceled: true };
    const filename = selected.filePaths[0];
    const text = readLimited(filename, MAX_FILE_BYTES);
    const result = kind === 'bookmarks' ? parseBookmarks(text) : parsePasswords(text);
    const { unique, duplicates } = partition(result.records, kind, spaceId);
    const token = crypto.randomUUID();
    const expiresAt = now() + PREVIEW_TTL_MS;
    pending = { token, kind, records: unique, total: result.total, skipped: result.skipped, duplicates, spaceId, expiresAt };
    pending.timer = setTimer(() => { if (pending && pending.token === token) clearPreview(); }, PREVIEW_TTL_MS);
    if (pending.timer && pending.timer.unref) pending.timer.unref();
    return {
      token, kind, source: path.basename(filename), spaceId, total: result.total, valid: result.records.length,
      duplicates, skipped: result.skipped, toImport: unique.length, expiresAt,
      sample: unique.slice(0, 8).map(({ title, url, username }) => kind === 'passwords' ? { title, url, username } : { title, url })
    };
  }

  async function commit(token) {
    if (!pending || typeof token !== 'string' || pending.token !== token) throw new Error('This import preview is no longer available. Choose the export again.');
    if (pending.expiresAt <= now()) { clearPreview(); throw new Error('The import preview expired. Choose the export again.'); }
    const review = pending;
    try {
      // Bind the import to the reviewed Space, even if the user switches Spaces.
      if (!getStore().spaces.some(space => space.id === review.spaceId)) throw new Error('The reviewed Space no longer exists. Choose the export again.');
      if (review.kind === 'passwords') requireEncryption();
      const { unique, duplicates } = partition(review.records, review.kind, review.spaceId);
      if (review.kind === 'bookmarks') {
        const store = getStore();
        const previous = store.bookmarks;
        store.bookmarks = [...unique.map(record => ({ ...record, at: now() })), ...store.bookmarks];
        try { await save(); } catch (error) { store.bookmarks = previous; throw error; }
      } else if (unique.length) {
        const vault = readVault();
        for (const { password, ...record } of unique) {
          const encryptedPassword = safeStorage.encryptString(password).toString('base64');
          vault.accounts.push({ ...record, id: crypto.randomUUID(), at: now(), encryptedPassword });
        }
        writeVault(vault);
      }
      publish();
      return { kind: review.kind, imported: unique.length, duplicates: review.duplicates + duplicates, skipped: review.skipped, spaceId: review.spaceId };
    } finally { clearPreview(); }
  }

  function cancel(token) {
    if (pending && pending.token === token) clearPreview();
    return { canceled: true };
  }
  function listAccounts() {
    return readVault().accounts.map(({ id, title, url, username, spaceId, at }) => ({ id, title, url, username, spaceId, at }));
  }
  function activeAccount(id, vault) {
    const record = vault.accounts.find(account => account.id === id && account.spaceId === getActiveSpace());
    if (!record) throw new Error('This saved account is not available in the current Space.');
    return record;
  }
  function clearCopiedText() {
    // Never erase newer clipboard content written by the user or another app.
    if (copiedText !== null && clipboard.readText() === copiedText) clipboard.clear();
    copiedText = null;
    clipboardTimer = null;
  }
  function copyAccount(id, field) {
    if (!['username', 'password'].includes(field)) throw new Error('Choose a username or password to copy.');
    const record = activeAccount(id, readVault());
    let value = record.username;
    if (field === 'password') {
      requireEncryption();
      try { value = safeStorage.decryptString(Buffer.from(record.encryptedPassword, 'base64')); }
      catch { throw new Error('This password could not be decrypted by this operating-system account.'); }
    }
    if (clipboardTimer) clearTimer(clipboardTimer);
    clipboard.writeText(value);
    copiedText = value;
    clipboardTimer = setTimer(clearCopiedText, CLIPBOARD_TTL_MS);
    if (clipboardTimer && clipboardTimer.unref) clipboardTimer.unref();
    return { copied: true, field, clearAfterSeconds: 30 };
  }
  function deleteAccount(id) {
    const vault = readVault();
    activeAccount(id, vault);
    vault.accounts = vault.accounts.filter(account => account.id !== id);
    writeVault(vault);
    publish();
    return { deleted: true };
  }
  function dispose() {
    clearPreview();
    if (clipboardTimer) clearTimer(clipboardTimer);
    clearCopiedText();
  }
  return { preview, commit, cancel, listAccounts, copyAccount, deleteAccount, dispose };
}

module.exports = { createImportService, parseBookmarks, parsePasswords, webUrl, MAX_FILE_BYTES };
