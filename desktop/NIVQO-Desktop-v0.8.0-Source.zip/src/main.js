'use strict';
const { app, BaseWindow, WebContentsView, ipcMain, session, dialog, shell, Menu, clipboard, safeStorage, nativeImage } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const { FlowLink, FILE_LIMIT, parsePairCode } = require('./flow');
const { createPairQr, decodeNativePairQr } = require('./pairing-qr');
const { createImportService } = require('./imports');
let importService;
let pairQr = '';
let pairQrCode = '';
// Development UI checks use a separate disposable profile, never the installed app profile.
if (!app.isPackaged && process.env.NIVQO_TEST_PROFILE) app.setPath('userData', path.resolve(process.env.NIVQO_TEST_PROFILE));

// The local browser chrome alone may invoke privileged app methods. Remote pages
// have no preload bridge, and IPC requests are rejected unless sent by chrome.
function handleTrusted(channel, handler) {
  ipcMain.handle(channel, (event, ...args) => {
    if (!chrome || event.sender !== chrome.webContents || event.senderFrame !== chrome.webContents.mainFrame) {
      throw new Error('Untrusted IPC sender');
    }
    return handler(event, ...args);
  });
}


// No application analytics or telemetry are implemented. Chromium network activity
// and website tracking are separate concerns: read PRIVACY.md before relying on this.
app.commandLine.appendSwitch('disable-background-networking');
app.commandLine.appendSwitch('disable-sync');
app.commandLine.appendSwitch('no-pings');
app.commandLine.appendSwitch('force-webrtc-ip-handling-policy', 'disable_non_proxied_udp');
app.setName('Nivqo Browser');

const HEADER_HEIGHT = 104;
const HOME = 'nivqo://newtab';
const MAX_HISTORY = 600;
const ALLOWED_SCHEMES = new Set(['http:', 'https:']);
const SEARCH = {
  duckduckgo: q => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
  brave: q => `https://search.brave.com/search?q=${encodeURIComponent(q)}`,
  google: q => `https://www.google.com/search?q=${encodeURIComponent(q)}`
};
const FALLBACK_TRACKERS = [
  'google-analytics.com', 'googletagmanager.com', 'doubleclick.net',
  'googlesyndication.com', 'connect.facebook.net', 'facebook.net',
  'analytics.twitter.com', 'ads-twitter.com', 'scorecardresearch.com',
  'hotjar.com', 'mixpanel.com', 'segment.io', 'segment.com',
  'amplitude.com', 'quantserve.com', 'criteo.com', 'taboola.com',
  'outbrain.com', 'branch.io', 'newrelic.com', 'clarity.ms',
  'bat.bing.com', 'pixel.wp.com', 'adsrvr.org', 'adnxs.com',
  'rubiconproject.com', 'pubmatic.com', 'openx.net', 'moatads.com',
  'chartbeat.net', 'static.ads-twitter.com'
];

let win;
let chrome;
let activeId = null;
let nextId = 1;
let tabs = [];
let downloads = [];
let filterEngine = null;
let filterUpdatedAt = 0;
let storageFile;
let store;
let saveTimer;
let isQuitting = false;
let panelVisible = false;
let activeSpace = 'personal';
const flow = new FlowLink();
let pendingTransfers = [];
const PENDING_TTL_MS = 10 * 60 * 1000;
let nextTransferId = 1;
let assistResult = null;
const privacyConfigured = new WeakSet();
const sessions = [];

const defaults = () => ({
  settings: { searchEngine: 'duckduckgo', blockTrackers: true, clearOnExit: false, saveHistory: true, theme: 'dark', smartSleep: false, sleepMinutes: 15 },
  spaces: [{ id: 'personal', name: 'Personal', color: '#27c9ff' }, { id: 'work', name: 'Work', color: '#8a83ff' }, { id: 'shopping', name: 'Shopping', color: '#61d7ac' }, { id: 'gaming', name: 'Gaming', color: '#ff74c7' }],
  bookmarks: [], history: [], restore: []
});
const cleanUrl = str => {
  try { const url = new URL(str); return ALLOWED_SCHEMES.has(url.protocol) ? url.href : null; }
  catch { return null; }
};
function toNavigation(input) {
  let value = String(input || '').trim();
  if (!value || value === HOME) return HOME;
  const parsed = cleanUrl(value);
  if (parsed) return parsed;
  // Reject explicitly-supplied nonweb protocols instead of interpreting them as URLs.
  if (/^[a-z][a-z\d+.-]*:\/\//i.test(value)) return null;
  if (/^(localhost|\d{1,3}(?:\.\d{1,3}){3})(:\d+)?(?:\/.*)?$/i.test(value)) return cleanUrl('http://' + value);
  if (/^[\w-]+(?:\.[\w-]+)+(?::\d+)?(?:[/?#].*)?$/i.test(value) && !/\s/.test(value)) return cleanUrl('https://' + value);
  const search = SEARCH[store.settings.searchEngine] || SEARCH.duckduckgo;
  return search(value);
}
function readStore() {
  const fallback = defaults();
  try {
    const saved = JSON.parse(fs.readFileSync(storageFile, 'utf8'));
    return {
      settings: { ...fallback.settings, ...(saved.settings || {}) },
      spaces: Array.isArray(saved.spaces) && saved.spaces.length ? saved.spaces.filter(x => /^[a-z0-9-]{1,32}$/.test(x.id || '') && typeof x.name === 'string').slice(0, 12) : fallback.spaces,
      bookmarks: Array.isArray(saved.bookmarks) ? saved.bookmarks.filter(b => cleanUrl(b.url)).map(b => ({...b, spaceId: b.spaceId || 'personal'})).slice(0, 1000) : [],
      history: Array.isArray(saved.history) ? saved.history.filter(h => cleanUrl(h.url)).map(h => ({...h, spaceId: h.spaceId || 'personal'})).slice(0, MAX_HISTORY) : [],
      restore: Array.isArray(saved.restore) ? saved.restore.filter(r => cleanUrl(r.url)).map(r => ({...r, spaceId:r.spaceId || 'personal'})).slice(0, 20) : []
    };
  } catch { return fallback; }
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(writeStore, 250);
}
function writeStore(strict = false) {
  if (!store || !storageFile) return;
  try {
    store.restore = store.settings.clearOnExit ? [] : tabs.filter(t => !t.private && cleanUrl(t.url)).map(t => ({ url: t.url, title: t.title, spaceId: t.spaceId })).slice(0, 20);
    fs.mkdirSync(path.dirname(storageFile), { recursive: true });
    const temp = storageFile + '.tmp';
    fs.writeFileSync(temp, JSON.stringify(store, null, 2), { mode: 0o600 });
    fs.renameSync(temp, storageFile);
  } catch (err) { if (strict) throw err; console.warn('Could not save local browser settings:', err.message); }
}
function getActive() { return tabs.find(t => t.id === activeId) || null; }
function exposedTab(t) {
  return {
    id: t.id, title: t.title || 'New Tab', url: t.url,
    private: t.private, spaceId: t.spaceId, sleeping: !!t.sleeping, loading: t.loading, blocked: t.blocked,
    canGoBack: !!t.view && t.view.webContents.navigationHistory.canGoBack(),
    canGoForward: !!t.view && t.view.webContents.navigationHistory.canGoForward(),
    favicon: t.favicon || null
  };
}
function accountSnapshot() {
  try { return { accounts: importService?.listAccounts() || [], accountsError: null }; }
  catch (error) { return { accounts: [], accountsError: error.message }; }
}
function snapshot() {
  return {
    version: app.getVersion(), profilePath: app.getPath('userData'), ...accountSnapshot(),
    tabs: tabs.map(exposedTab), activeId, activeSpace, spaces: store.spaces,
    flow: { status: flow.status, connected: flow.connected, pairCode: flow.pairCode, qr: pairQrCode === flow.pairCode ? pairQr : '', peerLabel: flow.peerLabel },
    pendingTransfers: pendingTransfers.map(p => ({id:p.id,type:p.type,label:p.label,size:p.size,receivedAt:p.receivedAt})), assistResult,
    settings: store.settings,
    bookmarks: store.bookmarks,
    history: store.history.slice(0, MAX_HISTORY),
    downloads: downloads.slice(0, 25),
    filterStatus: filterEngine ? 'full' : 'basic',
    lastFilterUpdate: filterUpdatedAt
  };
}
function publish() {
  if (chrome && !chrome.webContents.isDestroyed()) chrome.webContents.send('nivqo:state', snapshot());
}
function partitionFor(t) { return t.private ? `nivqo-private-${t.spaceId}` : `persist:nivqo-space-${t.spaceId}`; }
function getSession(isPrivate, spaceId = 'personal') { return session.fromPartition(partitionFor({private:isPrivate,spaceId})); }
function isFallbackTracker(input) {
  try {
    const host = new URL(input).hostname.toLowerCase();
    return FALLBACK_TRACKERS.some(t => host === t || host.endsWith('.' + t));
  } catch { return false; }
}
function addBlockedCount(details) {
  const tab = tabs.find(t => t.view && t.view.webContents.id === details.webContentsId);
  if (tab) { tab.blocked += 1; if (tab.id === activeId && tab.blocked % 2 === 1) publish(); }
}
function configurePrivacy(ses) {
  if (privacyConfigured.has(ses)) return;
  privacyConfigured.add(ses);
  sessions.push(ses);
  ses.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
  ses.setPermissionCheckHandler(() => false);
  ses.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (details, callback) => {
    const headers = { ...details.requestHeaders, DNT: '1', 'Sec-GPC': '1' };
    callback({ requestHeaders: headers });
  });
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (details, callback) => {
    if (store.settings.blockTrackers && details.resourceType !== 'mainFrame') {
      let deny = isFallbackTracker(details.url);
      if (!deny && filterEngine) {
        try {
          // Ghostery's established EasyList-compatible engine, not an unreviewed regex scraper.
          const { Request } = require('@ghostery/adblocker');
          const rawType = String(details.resourceType || 'other').replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase();
          const check = filterEngine.match(Request.fromRawDetails({
            url: details.url, sourceUrl: details.referrer || details.initiator || undefined,
            type: rawType
          }));
          deny = !!check.match;
        } catch { /* basic host blocking continues when a filter cannot be evaluated */ }
      }
      if (deny) { addBlockedCount(details); return callback({ cancel: true }); }
    }
    callback({ cancel: false });
  });
  ses.on('will-download', (_event, item) => {
    const id = String(Date.now()) + '-' + Math.random().toString(36).slice(2, 7);
    const entry = { id, name: item.getFilename(), progress: 0, state: 'starting' };
    downloads.unshift(entry);
    downloads = downloads.slice(0, 50);
    publish();
    item.on('updated', () => {
      entry.progress = item.getTotalBytes() > 0 ? Math.floor((item.getReceivedBytes() / item.getTotalBytes()) * 100) : 0;
      entry.state = 'downloading'; publish();
    });
    item.once('done', (_ev, status) => { entry.state = status; entry.progress = status === 'completed' ? 100 : entry.progress; publish(); });
  });
}
async function loadFilterEngine() {
  // Always retain an offline-capable local fallback. Filters can be cached locally.
  const filename = path.join(app.getPath('userData'), 'filters.bin');
  const { FiltersEngine } = require('@ghostery/adblocker');
  try {
    if (fs.existsSync(filename)) {
      filterEngine = FiltersEngine.deserialize(fs.readFileSync(filename));
      filterUpdatedAt = Math.round(fs.statSync(filename).mtimeMs);
      publish();
    }
  } catch (err) { console.warn('Cached filters are invalid:', err.message); }
  // Fetching public filter lists is not telemetry but does contact the list host.
  if (filterEngine && Date.now() - filterUpdatedAt < 7 * 24 * 60 * 60 * 1000) return;
  try {
    const engine = await FiltersEngine.fromPrebuiltAdsAndTracking(fetch);
    if (!isQuitting) {
      filterEngine = engine;
      filterUpdatedAt = Date.now();
      fs.writeFileSync(filename, Buffer.from(engine.serialize()), { mode: 0o600 });
      publish();
    }
  } catch (err) { console.warn('Using offline tracker protection:', err.message); }
}
function layout() {
  if (!win || !chrome) return;
  const { width, height } = win.getContentBounds();
  chrome.setBounds({ x: 0, y: 0, width, height });
  const tab = getActive();
  // A three-pixel bottom accent is reserved; websites otherwise use the full window.
  if (tab?.view) tab.view.setBounds({ x: 0, y: HEADER_HEIGHT, width: Math.max(1, width), height: Math.max(1, height - HEADER_HEIGHT - 3) });
}
function unmount(t) {
  if (t?.view) win.contentView.removeChildView(t.view);
}
function activate(id) {
  const selected = tabs.find(t => t.id === id);
  if (!selected) return;
  unmount(getActive());
  activeId = id;
  if (!selected.private) activeSpace = selected.spaceId;
  selected.lastActiveAt = Date.now();
  if (selected.sleeping) { selected.sleeping = false; selected.loaded = false; }
  if (selected.url !== HOME) {
    ensureView(selected);
    if (!panelVisible) win.contentView.addChildView(selected.view);
    if (!selected.loaded) navigateTab(selected, selected.url);
  }
  layout(); publish(); scheduleSave();
}
function newTab(url = HOME, isPrivate = false, select = true, spaceId = activeSpace) {
  const accepted = url === HOME ? HOME : cleanUrl(url);
  const t = { id: nextId++, url: accepted || HOME, title: 'New Tab', loading: false,
    blocked: 0, favicon: null, private: !!isPrivate, spaceId, view: null, loaded: false, sleeping: false, lastActiveAt: Date.now() };
  tabs.push(t);
  if (select) activate(t.id);
  else { publish(); scheduleSave(); }
  return t;
}
function ensureView(t) {
  if (t.view) return t.view;
  const ses = getSession(t.private, t.spaceId);
  configurePrivacy(ses);
  const view = new WebContentsView({
    webPreferences: {
      partition: partitionFor(t),
      sandbox: true, contextIsolation: true, nodeIntegration: false,
      webSecurity: true, webviewTag: false, javascript: true,
      backgroundThrottling: true
    }
  });
  t.view = view;
  const wc = view.webContents;
  wc.setWindowOpenHandler(({ url, disposition }) => {
    const safe = cleanUrl(url);
    if (safe) newTab(safe, t.private, disposition !== 'background-tab');
    return { action: 'deny' };
  });
  wc.on('will-navigate', (event, url) => { if (!cleanUrl(url)) event.preventDefault(); });
  wc.on('did-start-loading', () => { t.loading = true; publish(); });
  wc.on('did-stop-loading', () => { t.loading = false; publish(); });
  wc.on('did-navigate', (_event, url) => updateNav(t, url, true));
  wc.on('did-navigate-in-page', (_event, url, isMainFrame) => { if (isMainFrame) updateNav(t, url, false); });
  wc.on('page-title-updated', (_event, title) => {
    if (!t.private && t.url === HOME) return;
    t.title = String(title || 'New Tab').slice(0, 160);
    if (!t.private && store.history[0]?.url === t.url) store.history[0].title = t.title;
    publish(); scheduleSave();
  });
  wc.on('page-favicon-updated', (_event, favicons) => {
    // Avoid fetching site favicons a second time in the untrusted chrome UI.
    t.favicon = (favicons || []).find(s => /^data:image\//.test(s)) || null;
    publish();
  });
  wc.on('did-fail-load', (_event, code, message, url, isMainFrame) => {
    if (isMainFrame && code !== -3) { t.loading = false; t.title = `Can't load page (${code})`; publish(); }
  });
  wc.on('render-process-gone', () => { t.loading = false; t.title = 'Tab crashed — reload to retry'; publish(); });
  wc.on('before-input-event', (event, input) => { if (handleShortcut(event, input)) event.preventDefault(); });
  wc.on('context-menu', (_event, params) => {
    const items = [];
    if (params.linkURL && cleanUrl(params.linkURL)) {
      items.push({ label: 'Open link in new tab', click: () => newTab(params.linkURL, t.private) });
      items.push({ label: 'Copy link address', click: () => require('electron').clipboard.writeText(params.linkURL) });
      items.push({ type: 'separator' });
    }
    if (params.isEditable) {
      items.push({ label: 'Cut', role: 'cut' }, { label: 'Copy', role: 'copy' }, { label: 'Paste', role: 'paste' });
    } else if (params.selectionText) {
      items.push({ label: 'Copy', role: 'copy' });
    }
    if (items.length) items.push({ type: 'separator' });
    items.push({ label: 'Back', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() });
    items.push({ label: 'Forward', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() });
    items.push({ label: 'Reload', click: () => wc.reload() });
    items.push({ type: 'separator' }, { label: 'Inspect element', click: () => wc.inspectElement(params.x, params.y) });
    Menu.buildFromTemplate(items).popup({ window: win });
  });
  return view;
}
function updateNav(t, url, isDocumentNav) {
  const safe = cleanUrl(url);
  if (!safe) return;
  t.url = safe;
  if (isDocumentNav) { t.blocked = 0; t.favicon = null; }
  if (!t.private && store.settings.saveHistory) {
    if (store.history[0]?.url !== safe) {
      store.history.unshift({ url: safe, title: t.title, spaceId:t.spaceId, at: Date.now() });
      store.history = store.history.slice(0, MAX_HISTORY);
    }
  }
  publish(); scheduleSave();
}
function navigateTab(t, url) {
  const safe = url === HOME ? HOME : cleanUrl(url);
  if (!safe) return;
  t.url = safe;
  t.title = safe === HOME ? 'New Tab' : (() => { try { return new URL(safe).hostname; } catch { return 'Loading'; } })();
  t.loaded = safe !== HOME;
  if (safe === HOME) {
    if (t.view) { unmount(t); t.view.webContents.close(); t.view = null; }
    t.loading = false; t.blocked = 0; t.favicon = null;
  } else {
    ensureView(t);
    if (t.id === activeId && !panelVisible) win.contentView.addChildView(t.view);
    t.view.webContents.loadURL(safe).catch(err => console.warn('Page navigation failed:', err.message));
  }
  layout(); publish(); scheduleSave();
}
function closeTab(id) {
  const index = tabs.findIndex(t => t.id === id);
  if (index < 0) return;
  const old = tabs[index];
  unmount(old);
  if (old.view && !old.view.webContents.isDestroyed()) old.view.webContents.close();
  tabs.splice(index, 1);
  if (id === activeId) {
    activeId = null;
    if (tabs.length) activate(tabs[Math.max(0, index - 1)].id);
    else newTab();
  }
  if (old.private && !tabs.some(t => t.private && t.spaceId === old.spaceId)) getSession(true, old.spaceId).clearData().catch(() => {});
  publish(); scheduleSave();
}
function handleShortcut(event, input) {
  if (input.type !== 'keyDown') return false;
  const combo = process.platform === 'darwin' ? input.meta : input.control;
  const key = input.key.toLowerCase();
  if (combo && key === 'l') { chrome.webContents.focus(); chrome.webContents.send('nivqo:focus-address'); return true; }
  if (combo && key === 't') { newTab(); return true; }
  if (combo && key === 'w') { closeTab(activeId); return true; }
  if (combo && key === 'd') { doAction('toggle-bookmark'); return true; }
  if (combo && key === 'p') { doAction('print'); return true; }
  if (combo && key === '0') { doAction('zoom-reset'); return true; }
  if (combo && (key === '=' || key === '+')) { doAction('zoom-in'); return true; }
  if (combo && key === '-') { doAction('zoom-out'); return true; }
  if (combo && key === 'tab') {
    const pos = tabs.findIndex(t => t.id === activeId);
    activate(tabs[(pos + (input.shift ? tabs.length - 1 : 1)) % tabs.length].id);
    return true;
  }
  if (combo && key === 'r') { doAction('reload'); return true; }
  if (combo && key === 'f') { chrome.webContents.focus(); chrome.webContents.send('nivqo:focus-find'); return true; }
  if (combo && input.shift && key === 'n') { newTab(HOME, true); return true; }
  if (input.alt && (key === 'left' || key === 'right')) { doAction(key === 'left' ? 'back' : 'forward'); return true; }
  if (key === 'f5') { doAction('reload'); return true; }
  return false;
}
function doAction(action, value) {
  const t = getActive();
  if (!t) return;
  switch (action) {
    case 'back': if (t.view?.webContents.navigationHistory.canGoBack()) t.view.webContents.navigationHistory.goBack(); break;
    case 'forward': if (t.view?.webContents.navigationHistory.canGoForward()) t.view.webContents.navigationHistory.goForward(); break;
    case 'reload': if (t.view) t.view.webContents.reload(); break;
    case 'stop': if (t.view) t.view.webContents.stop(); break;
    case 'home': navigateTab(t, HOME); break;
    case 'navigate': { const url = toNavigation(value); if (url) navigateTab(t, url); break; }
    case 'find': if (t.view && value) t.view.webContents.findInPage(String(value).slice(0, 200)); break;
    case 'stop-find': if (t.view) t.view.webContents.stopFindInPage('clearSelection'); break;
    case 'devtools': if (t.view) t.view.webContents.openDevTools({ mode: 'detach' }); break;
    case 'print': if (t.view) t.view.webContents.print({ printBackground: true }); break;
    case 'zoom-in': if (t.view) t.view.webContents.setZoomFactor(Math.min(3, t.view.webContents.getZoomFactor() + 0.1)); break;
    case 'zoom-out': if (t.view) t.view.webContents.setZoomFactor(Math.max(0.5, t.view.webContents.getZoomFactor() - 0.1)); break;
    case 'zoom-reset': if (t.view) t.view.webContents.setZoomFactor(1); break;
    case 'toggle-bookmark': {
      if (!cleanUrl(t.url) || t.private) break;
      const i = store.bookmarks.findIndex(b => b.url === t.url && b.spaceId === t.spaceId);
      if (i >= 0) store.bookmarks.splice(i, 1);
      else store.bookmarks.unshift({ url: t.url, title: t.title, spaceId:t.spaceId, at: Date.now() });
      scheduleSave(); publish(); break;
    }
    case 'open-downloads': shell.openPath(app.getPath('downloads')).catch(() => {}); break;
  }
}
function createWindow() {
  win = new BaseWindow({ width: 1440, height: 900, minWidth: 790, minHeight: 540,
    title: 'Nivqo Browser', backgroundColor: '#0e111b', autoHideMenuBar: true });
  Menu.setApplicationMenu(null);
  chrome = new WebContentsView({ webPreferences: {
    preload: path.join(__dirname, 'preload.js'), sandbox: true,
    contextIsolation: true, nodeIntegration: false, webSecurity: true
  }});
  win.contentView.addChildView(chrome);
  chrome.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  // Never let the privileged browser interface navigate to a remote page.
  chrome.webContents.on('will-navigate', event => event.preventDefault());
  chrome.webContents.on('before-input-event', (event, input) => { if (handleShortcut(event, input)) event.preventDefault(); });
  chrome.webContents.loadFile(path.join(__dirname, 'index.html')).catch(console.error);
  chrome.webContents.on('did-finish-load', publish);
  win.on('resize', layout);
  win.on('closed', () => {
    clearTimeout(saveTimer);
    writeStore();
    for (const t of tabs) if (t.view && !t.view.webContents.isDestroyed()) t.view.webContents.close();
    if (chrome && !chrome.webContents.isDestroyed()) chrome.webContents.close();
    win = null;
  });
  const restore = store.restore;
  if (restore.length) {
    for (const [index, item] of restore.entries()) newTab(item.url, false, index === 0, store.spaces.some(s => s.id === item.spaceId) ? item.spaceId : 'personal');
  } else newTab();
  layout(); win.show();
}

handleTrusted('nivqo:get-state', () => snapshot());
handleTrusted('nivqo:import-preview', (_event, kind) => importService.preview(kind));
handleTrusted('nivqo:import-commit', (_event, token) => importService.commit(token));
handleTrusted('nivqo:import-cancel', (_event, token) => importService.cancel(token));
handleTrusted('nivqo:account-copy', (_event, id, field) => importService.copyAccount(id, field));
handleTrusted('nivqo:account-delete', (_event, id) => importService.deleteAccount(id));
handleTrusted('nivqo:panel-visible', (_event, visible) => {
  panelVisible = !!visible;
  const t = getActive();
  if (t?.view) {
    if (panelVisible) unmount(t);
    else win.contentView.addChildView(t.view);
    layout();
  }
  return true;
});
handleTrusted('nivqo:new-tab', (_event, opts = {}) => { newTab(HOME, !!opts.private); return true; });
handleTrusted('nivqo:activate-tab', (_event, id) => { activate(Number(id)); return true; });
handleTrusted('nivqo:close-tab', (_event, id) => { closeTab(Number(id)); return true; });
handleTrusted('nivqo:action', (_event, action, value) => { doAction(action, value); return true; });
handleTrusted('nivqo:open-url', (_event, url) => { const safe = toNavigation(url); if (safe) newTab(safe); return true; });
handleTrusted('nivqo:setting', async (_event, name, value) => {
  if (name === 'searchEngine' && ['duckduckgo','brave','google'].includes(value)) store.settings.searchEngine = value;
  if (name === 'theme' && ['dark', 'light'].includes(value)) store.settings.theme = value;
  if (['blockTrackers','clearOnExit','saveHistory','smartSleep'].includes(name) && typeof value === 'boolean') store.settings[name] = value;
  if (name === 'sleepMinutes' && [5,15,30,60].includes(Number(value))) store.settings.sleepMinutes = Number(value);
  scheduleSave(); publish(); return true;
});
handleTrusted('nivqo:clear-data', async () => {
  store.history = []; store.restore = [];
  await Promise.all(sessions.map(s => s.clearData().catch(() => {})));
  scheduleSave(); publish(); return true;
});
handleTrusted('nivqo:clear-history', () => { store.history = []; scheduleSave(); publish(); return true; });


function switchSpace(id) {
  if (!store.spaces.some(s => s.id === id)) return false;
  activeSpace = id;
  let tab = tabs.find(t => !t.private && t.spaceId === id);
  if (!tab) tab = newTab(HOME, false, false, id);
  activate(tab.id); return true;
}
function createSpace(name) {
  name = String(name || '').trim().slice(0, 28);
  if (!name || store.spaces.length >= 12) throw new Error('Enter a space name (maximum 12 spaces)');
  const id = require('node:crypto').randomBytes(7).toString('hex');
  store.spaces.push({ id, name, color: ['#27c9ff','#8a83ff','#61d7ac','#ffa36d'][store.spaces.length % 4] });
  scheduleSave(); switchSpace(id); return true;
}
function onIncomingTransfer({type,data}) {
  if (!data || typeof data !== 'object') return;
  let label = '', size = 0;
  if (type === 'flow-tab' && cleanUrl(data.url) && String(data.url).length <= 4096) {
    label = `Tab: ${String(data.title || data.url).slice(0,100)}`;
  } else if (type === 'drop-text' && typeof data.text === 'string' && data.text.length <= 100000) {
    label = `Text: ${data.text.slice(0,80)}`; size = Buffer.byteLength(data.text);
  } else if (type === 'drop-file' && typeof data.data === 'string' && typeof data.name === 'string') {
    size = Buffer.byteLength(data.data, 'base64');
    if (size > FILE_LIMIT) return;
    label = `File: ${path.basename(data.name).slice(0,120)}`;
  } else return;
  pendingTransfers = pendingTransfers.filter(t => Date.now() - t.receivedAt < PENDING_TTL_MS).slice(-7);
  pendingTransfers.push({id:nextTransferId++,type,data,label,size,receivedAt:Date.now()});
  publish();
}
flow.on('status', () => {
  if (flow.pairCode !== pairQrCode) { pairQr = ''; pairQrCode = ''; }
  publish();
});
flow.on('message', onIncomingTransfer);
flow.on('error', err => { console.warn('Flow link error:', err.message); if (chrome && !chrome.webContents.isDestroyed()) chrome.webContents.send('nivqo:flow-error', err.message); });
handleTrusted('nivqo:space-switch', (_event,id) => switchSpace(String(id || '')));
handleTrusted('nivqo:space-add', (_event,name) => createSpace(name));
handleTrusted('nivqo:flow-host', async () => {
  const code = await flow.host();
  const qr = await createPairQr(code);
  if (flow.pairCode === code) { pairQrCode = code; pairQr = qr; publish(); }
  return true;
});
handleTrusted('nivqo:flow-read-qr', async () => {
  const selected = await dialog.showOpenDialog(win, { title: 'Choose a pairing QR image', properties: ['openFile'], filters: [{ name: 'PNG QR images', extensions: ['png'] }] });
  if (selected.canceled || !selected.filePaths.length) return { canceled: true };
  const file = selected.filePaths[0];
  const stat = await fs.promises.stat(file);
  if (!stat.isFile() || stat.size > 8 * 1024 * 1024) throw new Error('Choose a PNG image smaller than 8 MB');
  const code = decodeNativePairQr(await fs.promises.readFile(file), nativeImage);
  const { host, port } = parsePairCode(code);
  return { code, host, port };
});
handleTrusted('nivqo:flow-join', (_event,code) => flow.join(code));
handleTrusted('nivqo:flow-disconnect', () => { flow.disconnect(); return true; });
handleTrusted('nivqo:flow-copy-code', () => {
  if (!flow.pairCode) throw new Error('No active pairing code');
  clipboard.writeText(flow.pairCode); return true;
});
handleTrusted('nivqo:flow-send-tab', async () => {
  const tab = getActive();
  if (!tab || tab.private || !cleanUrl(tab.url)) throw new Error('Only ordinary web tabs can be sent');
  let scrollY = 0;
  try { scrollY = await tab.view?.webContents.executeJavaScript('Math.max(0, Math.round(window.scrollY))'); } catch {}
  return flow.send('flow-tab', { url:tab.url, title:tab.title.slice(0,160),scrollY:Math.min(10000000,scrollY || 0) });
});
handleTrusted('nivqo:flow-send-text', (_event,text) => flow.send('drop-text',{text:String(text || '').slice(0,100000)}));
handleTrusted('nivqo:flow-send-file', async () => {
  if (!flow.connected) throw new Error('Pair a device first');
  const selected = await dialog.showOpenDialog(win,{properties:['openFile'],title:'Choose file to send (4 MB maximum)'});
  if (selected.canceled || !selected.filePaths.length) return false;
  const file = selected.filePaths[0];
  const stat = await fs.promises.stat(file);
  if (!stat.isFile() || stat.size > FILE_LIMIT) throw new Error('File must be 4 MB or smaller');
  const data = await fs.promises.readFile(file);
  return flow.send('drop-file',{name:path.basename(file),data:data.toString('base64')});
});
handleTrusted('nivqo:flow-accept', async (_event,id) => {
  const i = pendingTransfers.findIndex(p => p.id === Number(id));
  if (i < 0) return false;
  const item = pendingTransfers.splice(i,1)[0]; publish();
  if (Date.now() - item.receivedAt > PENDING_TTL_MS) throw new Error('Transfer expired');
  if (item.type === 'flow-tab') {
    const tab = newTab(item.data.url,false,true);
    if (item.data.scrollY && tab.view) {
      tab.view.webContents.once('did-finish-load', () => {
        const y = Math.min(10000000,Math.max(0,Number(item.data.scrollY)||0));
        tab.view.webContents.executeJavaScript(`window.scrollTo(0,${y})`).catch(()=>{});
      });
    }
    return true;
  }
  if (item.type === 'drop-text') {
    require('electron').clipboard.writeText(item.data.text);
    return true;
  }
  if (item.type === 'drop-file') {
    const result = await dialog.showSaveDialog(win,{title:'Save received file',defaultPath:path.join(app.getPath('downloads'),path.basename(item.data.name))});
    if (result.canceled || !result.filePath) return false;
    await fs.promises.writeFile(result.filePath,Buffer.from(item.data.data,'base64'),{mode:0o600});
    return true;
  }
  return false;
});
handleTrusted('nivqo:flow-decline', (_event,id) => {
  pendingTransfers = pendingTransfers.filter(p => p.id !== Number(id)); publish(); return true;
});
function extractBrief(raw) {
  const text = String(raw.text || '').replace(/\s+/g,' ').trim().slice(0,60000);
  if (!text) throw new Error('This page has no readable text');
  const sentences = text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [];
  const highlights = sentences.map(s => s.trim()).filter(s => s.length >= 65 && s.length <= 280).slice(0,200).slice(0,4);
  return {title:String(raw.title || '').slice(0,160), site: String(raw.url || '').slice(0,300), estimatedMinutes:Math.max(1,Math.ceil(text.split(/\s+/).length/220)), headings:(raw.headings || []).slice(0,7), highlights, generatedAt:Date.now(),note:'Offline extractive reading brief — no AI model is used. Text is not uploaded.'};
}
handleTrusted('nivqo:assist-brief', async () => {
  const tab = getActive();
  if (!tab?.view) throw new Error('Open a webpage first');
  const raw = await tab.view.webContents.executeJavaScript(`(() => {
    const root = document.querySelector('article') || document.querySelector('main') || document.body;
    return {title:document.title,url:location.href,text:(root?.innerText||'').slice(0,60000),headings:[...document.querySelectorAll('article h1, article h2, main h1, main h2')].slice(0,7).map(n=>n.innerText.slice(0,130))};
  })()`);
  assistResult = extractBrief(raw); publish(); return assistResult;
});
function sleepInactiveTabs() {
  if (!store?.settings.smartSleep || !win) return;
  const threshold = Number(store.settings.sleepMinutes || 15)*60000;
  for(const t of tabs) {
    if (t.id === activeId || t.private || !t.view || !t.loaded || !cleanUrl(t.url) || Date.now() - t.lastActiveAt < threshold) continue;
    try { if (t.view.webContents.isCurrentlyAudible?.() || t.view.webContents.isLoading()) continue; } catch {continue;}
    unmount(t);t.view.webContents.close();t.view=null;t.loaded=false;t.sleeping=true;
  }
  publish();
}
setInterval(sleepInactiveTabs,60000).unref?.();
setInterval(() => {
  const n = pendingTransfers.length;
  pendingTransfers = pendingTransfers.filter(t => Date.now() - t.receivedAt < PENDING_TTL_MS);
  if (pendingTransfers.length !== n) publish();
}, 60000).unref?.();

app.whenReady().then(async () => {
  storageFile = path.join(app.getPath('userData'), 'state.json');
  store = readStore();
  importService = createImportService({ app, dialog, safeStorage, clipboard,
    getStore: () => store, save: () => writeStore(true), publish,
    getActiveSpace: () => activeSpace, getWindow: () => win });
  for (const sp of store.spaces) { configurePrivacy(getSession(false,sp.id)); configurePrivacy(getSession(true,sp.id)); }
  createWindow();
  // Do not block startup on downloading lists: offline protection is active immediately.
  loadFilterEngine().catch(err => console.warn(err.message));
  app.on('activate', () => { if (!win) createWindow(); });
}).catch(console.error);
app.on('before-quit', async e => {
  flow.disconnect();
  importService?.dispose();
  if (isQuitting) return;
  isQuitting = true;
  clearTimeout(saveTimer);
  if (store?.settings.clearOnExit) {
    e.preventDefault();
    store.history = []; store.restore = [];
    writeStore();
    await Promise.all(sessions.map(s => s.clearData().catch(() => {})));
    app.exit(0);
  } else writeStore();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
