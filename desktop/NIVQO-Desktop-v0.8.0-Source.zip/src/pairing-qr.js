'use strict';
const QRCode = require('qrcode');
const jsQR = require('jsqr');
const { parsePairCode } = require('./flow');

async function createPairQr(code) {
  parsePairCode(code);
  return QRCode.toDataURL(code, { errorCorrectionLevel: 'M', margin: 4, width: 384, color: { dark: '#061121ff', light: '#ffffffff' } });
}
function validatePng(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length > 8 * 1024 * 1024 || bytes.length < 33 ||
      !bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) || bytes.toString('ascii', 12, 16) !== 'IHDR') {
    throw new Error('Choose a PNG QR image smaller than 8 MB');
  }
  const width = bytes.readUInt32BE(16), height = bytes.readUInt32BE(20);
  if (!width || !height || width > 4096 || height > 4096 || width * height > 12000000) throw new Error('QR image dimensions are too large');
  return { width, height };
}
function decodePairQr(rgba, width, height) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width * height > 12000000 || rgba.length !== width * height * 4) throw new Error('Invalid QR image');
  const result = jsQR(new Uint8ClampedArray(rgba), width, height, { inversionAttempts: 'attemptBoth' });
  if (!result) throw new Error('No QR code found. Use a clear, uncropped PNG image');
  parsePairCode(result.data);
  return result.data;
}
function decodeNativePairQr(bytes, nativeImage) {
  validatePng(bytes);
  const image = nativeImage.createFromBuffer(bytes);
  if (image.isEmpty()) throw new Error('This PNG image could not be read');
  const { width, height } = image.getSize();
  const bgra = image.toBitmap();
  const rgba = new Uint8ClampedArray(bgra.length);
  for (let i = 0; i < bgra.length; i += 4) {
    rgba[i] = bgra[i + 2]; rgba[i + 1] = bgra[i + 1]; rgba[i + 2] = bgra[i]; rgba[i + 3] = bgra[i + 3];
  }
  return decodePairQr(rgba, width, height);
}
module.exports = { createPairQr, validatePng, decodePairQr, decodeNativePairQr };
