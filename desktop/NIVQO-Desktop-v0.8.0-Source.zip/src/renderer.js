'use strict';
const $ = id => document.getElementById(id);
const bridge = window.nivqo;
let state = { tabs: [], activeId: null, bookmarks: [], history: [], downloads: [], settings: { theme:'dark', blockTrackers:true, searchEngine:'duckduckgo', saveHistory:true, clearOnExit:false, smartSleep:false,sleepMinutes:15 }, filterStatus:'basic' };
let panel = null;
let panelSignature = '';
let importPreview = null;
let joinDraft = '';
let dropDraft = '';
let focusedAddress = false;
let lastRenderedTabs = '';
const active = () => state.tabs.find(t => t.id === state.activeId) || null;
const call = (name, value) => bridge?.action(name, value);
function htmlNode(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = String(text);
  return el;
}
function setActivePanel(next) {
  if (panel === 'imports' && next !== 'imports' && importPreview) { bridge?.importCancel(importPreview.token); importPreview = null; }
  if (next !== panel) { panelSignature = ''; $('panel').scrollTop = 0; }
  panel = next; bridge?.setPanelVisible(!!next); render(); }
function renderTabs() {
  const visible = state.tabs.filter(t => t.spaceId === (state.activeSpace || 'personal'));
  const sig = JSON.stringify(visible.map(t => [t.id,t.title,t.loading,t.private,t.sleeping,t.favicon,state.activeId]));
  if (sig === lastRenderedTabs) return;
  lastRenderedTabs = sig;
  const root = $('tabs'); root.replaceChildren();
  for (const t of visible) {
    const el = htmlNode('div', 'tab' + (t.id===state.activeId ? ' active' : ''));
    el.tabIndex=0; el.setAttribute('role','tab'); el.onkeydown=e=>{if(e.target===el&&(e.key==='Enter'||e.key===' ')){e.preventDefault();setActivePanel(null);bridge?.activateTab(t.id);}}; el.setAttribute('aria-selected',String(t.id===state.activeId)); el.title=t.title;
    let ico;
    if (t.favicon) { ico=htmlNode('img','tab-favicon'); ico.src=t.favicon; ico.onerror=()=>{ ico.replaceWith(htmlNode('span','tab-dot','◈')); }; }
    else ico=htmlNode('span','tab-dot', t.private ? '◉' : '◈');
    const title = htmlNode('span','tab-title',t.loading ? 'Loading…' : (t.sleeping ? '☾ ' : '')+t.title);
    const close=htmlNode('button','tab-close','×'); close.type='button'; close.title='Close tab';
    close.addEventListener('click', e=> {e.stopPropagation(); bridge?.closeTab(t.id);});
    el.append(ico,title,close); el.addEventListener('click',()=>{ setActivePanel(null); bridge?.activateTab(t.id); });
    root.append(el);
  }
}
function renderToolbar() {
  const tab=active(), url=tab?.url||'nivqo://newtab';
  if (!focusedAddress) $('address').value = url==='nivqo://newtab' ? '' : url;
  $('secureIcon').textContent = url.startsWith('https://') ? '▣' : url.startsWith('http://') ? '!' : '✧';
  $('secureIcon').title = url.startsWith('https://') ? 'Encrypted HTTPS connection' : url.startsWith('http://') ? 'Unencrypted HTTP connection' : 'New tab';
  $('back').disabled=!tab?.canGoBack; $('forward').disabled=!tab?.canGoForward;
  $('reload').textContent=tab?.loading ? '×' : '↻';
  $('star').textContent=state.bookmarks.some(b=>b.url===url && b.spaceId===(tab?.spaceId || 'personal')) ? '★' : '☆';
  $('star').disabled=!!tab?.private || !/^https?:\/\//.test(url);
  $('blockedCount').textContent=String(tab?.blocked||0);
  $('shield').style.opacity=state.settings.blockTrackers ? '1' : '.45';
  document.body.dataset.theme=state.settings.theme || 'dark';
}
function render() {
  renderSpaces(); renderTabs(); renderToolbar();
  const tab=active();
  const showPanel=!!panel;
  $('homeScreen').classList.toggle('hidden', showPanel || (!!tab && tab.url!=='nivqo://newtab'));
  $('panel').classList.toggle('hidden', !showPanel);
  if(showPanel) renderPanel();
  document.querySelector('.privacy-status span:last-child').textContent=state.settings.blockTrackers ? 'Tracking protection is active' : 'Tracking protection is paused';
}

let lastSpaceSignature = '';
function renderSpaces() {
  const sig=JSON.stringify([state.activeSpace,state.spaces]);
  if(sig===lastSpaceSignature)return;
  lastSpaceSignature=sig;
  const currentSpace=(state.spaces || []).find(space=>space.id===(state.activeSpace || 'personal'));
  const color=/^#[0-9a-f]{6}$/i.test(currentSpace?.color || '') ? currentSpace.color : '#27c9ff';
  document.documentElement.style.setProperty('--space-color',color);
  const select=$('spaceSelect');select.replaceChildren();
  for(const space of state.spaces || [{id:'personal',name:'Personal'}]) {
    const opt=htmlNode('option','',space.name);opt.value=space.id;
    if(space.id===(state.activeSpace||'personal')) opt.selected=true;
    select.append(opt);
  }
}
function notify(message,isError=false){
  const el=$('notice');el.textContent=String(message);el.classList.remove('hidden');el.classList.toggle('error',!!isError);
  // User-dismissed notice rather than a timer or automatic notification.
  el.onclick=()=>el.classList.add('hidden');
}
function actionButton(label,onClick,cls='primary-action'){
  const b=htmlNode('button',cls,label);
  b.onclick=async()=>{b.disabled=true;try {await onClick();} catch(e){notify(e?.message || String(e),true);}finally{b.disabled=false;}};
  return b;
}
function paragraph(root,text){root.append(htmlNode('p','help-text',text));}
function renderSpacesPanel(root){
  root.append(htmlNode('h3','','Separate browsing identities'));
  paragraph(root,'Each Space has its own Chromium cookies, local storage and cache. Bookmarks and history are tagged by Space. Switching Spaces does not log you into NIVQO.');
  for(const space of state.spaces||[]){
    const row=htmlNode('div','space-row');
    const dot=htmlNode('div','space-dot');dot.style.background=space.color || '#27c9ff';
    const text=htmlNode('div','space-info');text.append(htmlNode('strong','',space.name),htmlNode('small','',`${state.tabs.filter(t=>t.spaceId===space.id).length} tabs · ${state.bookmarks.filter(b=>b.spaceId===space.id).length} bookmarks`));
    row.append(dot,text,actionButton(space.id===state.activeSpace?'Current Space':'Switch',async()=>{setActivePanel(null);await bridge.switchSpace(space.id);},'outline-btn'));root.append(row);
  }
  root.append(htmlNode('h3','','Add a new Space'));
  const row=htmlNode('div','input-action');const input=htmlNode('input');input.placeholder='e.g. Research';input.maxLength=28;
  row.append(input,actionButton('Create Space',async()=>{if(!input.value.trim())throw new Error('Enter a name');await bridge.addSpace(input.value);setActivePanel(null);}));root.append(row);
  paragraph(root,'Private tabs remain memory-only. Tabs in an inactive Space may still run in the background unless NIVQO Boost puts them to sleep.');
}
function surface(title, description) {
  const card = htmlNode('section','surface-card');
  card.append(htmlNode('h3','',title));
  if(description) paragraph(card,description);
  return card;
}
function labeledInput(label, placeholder, value, onInput, rows=3) {
  const wrap=htmlNode('label','field-label',label);
  const input=htmlNode('textarea'); input.placeholder=placeholder; input.rows=rows; input.value=value;
  input.oninput=()=>onInput(input.value); wrap.append(input); return {wrap,input};
}
function renderFlowPanel(root){
  paragraph(root,'Pair an iPhone or another computer on the same Wi-Fi. Send a tab, a note or a file directly between your devices.');
  const stat=state.flow || {status:'disconnected'};
  const status=htmlNode('div','connection-status',stat.connected?'● Connected · ready to send':stat.status==='awaiting-pair'?'◌ Ready to pair · code expires after two minutes':'○ No device connected');
  status.classList.toggle('online',!!stat.connected); root.append(status);
  if(!stat.connected){
    const grid=htmlNode('div','flow-grid');
    const host=surface('1. Show a pairing QR','On iPhone, open NIVQO → Flow + Drop → Scan QR. Keep both devices on the same Wi-Fi.');
    if(stat.pairCode && stat.qr){
      const image=htmlNode('img','pair-qr');image.src=stat.qr;image.alt='Temporary QR code for pairing this computer';host.append(image);
      host.append(htmlNode('p','qr-caption','Scan with the NIVQO iPhone app'));
      const code=htmlNode('details','pair-code-details');code.append(htmlNode('summary','','Show pairing code'),htmlNode('div','pairing-box',stat.pairCode));host.append(code);
      const buttons=htmlNode('div','button-row');buttons.append(actionButton('Copy code',async()=>{await bridge.flowCopyCode();notify('Pairing code copied');},'outline-btn'),actionButton('Cancel pairing',async()=>bridge.flowDisconnect(),'outline-btn'));host.append(buttons);
    } else {
      const empty=htmlNode('div','qr-placeholder');empty.append(htmlNode('span','','▦'),htmlNode('p','','Your QR code appears here'));
      host.append(empty,actionButton(stat.pairCode?'Regenerate QR code':'Create pairing QR',async()=>{await bridge.flowHost();notify('Pairing QR ready for two minutes');}));
    }
    paragraph(host,'This temporary QR grants access to pairing. Share it only with the device you intend to connect.');
    const join=surface('2. Or connect this computer','Use a pairing code or a PNG QR image from another NIVQO computer.');
    const field=labeledInput('Pairing code','nivqo-pair://…',joinDraft,v=>joinDraft=v,4);join.append(field.wrap);
    const buttons=htmlNode('div','button-row');
    buttons.append(actionButton('Read QR image',async()=>{const r=await bridge.flowReadQr();if(!r.canceled){joinDraft=r.code;field.input.value=r.code;notify('QR read from '+r.host+'. Select Pair with device to connect.');}},'outline-btn'),actionButton('Pair with device',async()=>{await bridge.flowJoin(field.input.value);joinDraft='';notify('Secure pairing complete');}));join.append(buttons);
    const steps=htmlNode('ol','guide-list');for(const text of ['Open Flow + Drop on your other device.','Create a QR code on the hosting computer.','Scan it with iPhone, or read its PNG here.','Approve incoming items before opening or saving them.'])steps.append(htmlNode('li','',text));join.append(steps);
    grid.append(host,join);root.append(grid);
  } else {
    const grid=htmlNode('div','flow-grid');
    const tabs=surface('Flow · send a tab','Move the current webpage to your paired device. Private tabs stay on this computer.');
    tabs.append(actionButton('Send current tab',async()=>{await bridge.flowSendTab();notify('Tab sent for approval');}));
    tabs.append(actionButton('Disconnect',async()=>bridge.flowDisconnect(),'outline-btn'));
    const drop=surface('Drop · text & files','Send a note or choose a file up to 4 MB.');
    const field=labeledInput('Text to send','Write a note…',dropDraft,v=>dropDraft=v);field.input.maxLength=100000;drop.append(field.wrap);
    const buttons=htmlNode('div','button-row');buttons.append(actionButton('Send text',async()=>{if(!field.input.value.trim())throw new Error('Enter some text first');await bridge.flowSendText(field.input.value);dropDraft='';field.input.value='';notify('Text sent for approval');}),actionButton('Choose file',async()=>{if(await bridge.flowSendFile())notify('File sent for approval');},'outline-btn'));drop.append(buttons);grid.append(tabs,drop);root.append(grid);
  }
  const incoming=surface('Incoming transfers','You decide which tabs, text and files to accept.');
  if(!(state.pendingTransfers||[]).length)incoming.append(htmlNode('div','list-empty compact','Nothing waiting. Your next transfer will appear here.'));
  for(const p of state.pendingTransfers||[]){
    const row=htmlNode('div','entry');const content=htmlNode('div','entry-content');content.append(htmlNode('strong','',p.label),htmlNode('small','',p.type==='drop-file' ? Math.ceil(p.size/1024)+' KB · choose where to save':p.type==='drop-text'?'Accept to copy to your clipboard':'Accept to open a new tab'));
    row.append(content,actionButton('Accept',async()=>{if(await bridge.flowAccept(p.id))notify('Transfer accepted');},'outline-btn'),actionButton('Decline',async()=>bridge.flowDecline(p.id),'outline-btn'));incoming.append(row);
  }
  root.append(incoming);
  paragraph(root,'Direct, encrypted local-network transfers. No NIVQO account or cloud relay. Both devices must keep NIVQO open; iPhone transfers work while the app is in the foreground.');
}
function renderImportsPanel(root){
  if(state.accountsError) root.append(htmlNode('p','help-text',state.accountsError));
  const space=(state.spaces||[]).find(x=>x.id===state.activeSpace)?.name||'Personal';
  paragraph(root,'Bring bookmarks and saved passwords from Brave, Vivaldi, Chrome, Edge or another browser using its export files. Imported items are added to your '+space+' Space.');
  const grid=htmlNode('div','flow-grid');
  async function choose(kind){const result=await bridge.importPreview(kind);if(!result.canceled){importPreview=result;panelSignature='';renderPanel();}}
  const bookmarks=surface('Bookmarks','Choose an exported HTML bookmarks file or a Chromium Bookmarks JSON file.');
  bookmarks.append(actionButton('Choose bookmarks file',()=>choose('bookmarks')));
  const passwords=surface('Saved passwords','Choose a password CSV exported by your browser. Passwords are encrypted for your operating-system account before they are saved.');
  passwords.append(actionButton('Choose password CSV',()=>choose('passwords')));grid.append(bookmarks,passwords);root.append(grid);
  if(importPreview){
    const p=importPreview;const review=surface('Review your import',p.source+' · '+p.toImport+' new items · '+p.duplicates+' duplicates · '+p.skipped+' skipped');
    for(const item of p.sample||[]){const row=htmlNode('div','entry');const info=htmlNode('div','entry-content');info.append(htmlNode('strong','',item.title||item.url),htmlNode('small','',item.url+(item.username?' · '+item.username:'')));row.append(info);review.append(row);}
    const buttons=htmlNode('div','button-row');buttons.append(actionButton('Import '+p.toImport+' items',async()=>{const result=await bridge.importCommit(p.token);importPreview=null;panelSignature='';renderPanel();notify('Imported '+result.imported+' '+(result.kind==='bookmarks'?'bookmarks':'saved accounts'));}),actionButton('Cancel',async()=>{await bridge.importCancel(p.token);importPreview=null;panelSignature='';renderPanel();},'outline-btn'));review.append(buttons);root.append(review);
  }
  const accounts=surface('Saved accounts','Use Copy username or Copy password when signing in. Copied values clear after 30 seconds if the clipboard has not changed.');
  const list=(state.accounts||[]).filter(x=>x.spaceId===(state.activeSpace||'personal'));
  if(!list.length)accounts.append(htmlNode('div','list-empty compact','No imported accounts in this Space yet.'));
  for(const item of list){
    const row=htmlNode('div','account-row');const info=htmlNode('div','entry-content');info.append(htmlNode('strong','',item.title||item.url),htmlNode('small','',item.url),htmlNode('small','',item.username||'(no username)'));
    const buttons=htmlNode('div','button-row');buttons.append(actionButton('Open site',async()=>{setActivePanel(null);await bridge.openUrl(item.url);},'outline-btn'),actionButton('Copy username',async()=>{await bridge.accountCopy(item.id,'username');notify('Username copied for 30 seconds');},'outline-btn'),actionButton('Copy password',async()=>{await bridge.accountCopy(item.id,'password');notify('Password copied for 30 seconds');},'outline-btn'),actionButton('Remove',async()=>{if(confirm('Remove this saved account from NIVQO?'))await bridge.accountDelete(item.id);},'outline-btn'));row.append(info,buttons);accounts.append(row);
  }
  root.append(accounts);
  const guide=surface('How to export','In your current browser, open the bookmark manager and choose Export bookmarks. For passwords, open its password manager and choose Export passwords. Then choose the exported file above.');
  paragraph(guide,'Password CSV files contain readable passwords. Keep them private and remove the export when you no longer need it. Imports do not transfer cookies, open sessions, passkeys, payment cards or a Google/Brave/Vivaldi sync account. Sign in to websites again using your saved credentials.');root.append(guide);
}
function renderUpdatesPanel(root){
  root.append(htmlNode('div','version-badge','NIVQO '+(state.version||'0.8.0')+' · Desktop alpha'));
  const card=surface('Update with a new installer','Your browser uses manual updates. There is no background update download.');
  const steps=htmlNode('ol','guide-list');for(const text of ['Save your work and close every NIVQO window.','Download the next NIVQO Windows x64 installer from your trusted release source.','Run the installer using the same Windows account and installation location.','Open NIVQO. Your local Spaces, bookmarks and settings stay in your existing profile.'])steps.append(htmlNode('li','',text));card.append(steps);root.append(card);
  paragraph(root,'Local profile: '+(state.profilePath||'Available when running NIVQO desktop'));
  paragraph(root,'The source project includes a release guide, Windows build workflow and checksum generator. Keep a backup of your profile before upgrading. This alpha build is unsigned.');
}
function renderBoostPanel(root){
  root.append(htmlNode('h3','','Lightweight, on your terms'));
  paragraph(root,'NIVQO uses Chromium background throttling. Experimental tab sleeping can free inactive tab resources, but reloading a tab can lose unsaved form data.');
  root.append(settingRow('Sleep inactive tabs','Disabled by default to avoid unexpectedly discarding form data.','toggle',!!state.settings.smartSleep,v=>bridge.setSetting('smartSleep',v)));
  root.append(settingRow('Sleep after','Inactivity duration for ordinary background tabs.','select',String(state.settings.sleepMinutes||15),v=>bridge.setSetting('sleepMinutes',Number(v)),[['5','5 minutes'],['15','15 minutes'],['30','30 minutes'],['60','60 minutes']]));
  const sleeping=(state.tabs||[]).filter(t=>t.sleeping).length;
  root.append(htmlNode('div','metric-large',`${sleeping} sleeping tabs`));
  paragraph(root,'Open a sleeping tab to reload it. Memory and CPU reductions vary by website and have not been benchmarked. Audio-playing tabs and private tabs are excluded.');
}
function renderAssistPanel(root){
  root.append(htmlNode('h3','','A reading brief, without uploading the page'));
  paragraph(root,'Click to extract a few important sentences and headings from the current webpage. This first version uses offline text extraction, not a large language model. It never runs automatically.');
  root.append(actionButton('Generate local reading brief',async()=>{await bridge.assistBrief();notify('Reading brief ready');}));
  if(state.assistResult){const v=state.assistResult;
    const box=htmlNode('div','brief-result');box.append(htmlNode('h3','',v.title||'Reading brief'),htmlNode('p','muted',`About ${v.estimatedMinutes} min read`));
    if(v.headings?.length){box.append(htmlNode('strong','','Page headings'));for(const x of v.headings)box.append(htmlNode('p','brief-line','• '+x));}
    if(v.highlights?.length){box.append(htmlNode('strong','','Selected excerpts'));for(const x of v.highlights)box.append(htmlNode('p','brief-line','• '+x));}
    box.append(htmlNode('small','muted',v.note));root.append(box);
  }
  paragraph(root,'Future: optional on-device language model with per-page permission, source citations and zero cloud processing as the default.');
}

function settingRow(title, description, type, value, onChange, options) {
  const row=htmlNode('div','setting-row');
  const info=htmlNode('div','setting-info');
  info.append(htmlNode('strong','',title),htmlNode('p','',description));
  let control;
  if (type==='toggle') {
    control=htmlNode('button','switch'+(value?' on':''));
    control.type='button';control.setAttribute('role','switch');control.setAttribute('aria-label',title);control.setAttribute('aria-checked',String(value));
    control.onclick=()=>onChange(!value);
  } else {
    control=htmlNode('select');control.setAttribute('aria-label',title);
    for (const [v,label] of options) {
      const option=htmlNode('option','',label);option.value=v;if(value===v)option.selected=true;control.append(option);
    }
    control.onchange=()=>onChange(control.value);
  }
  row.append(info,control);return row;
}
function entryRow(item, icon, actionLabel, onAction, secondaryAction) {
  const el=htmlNode('div','entry');el.append(htmlNode('div','entry-icon',icon));
  const content=htmlNode('div','entry-content');content.append(htmlNode('strong','',item.title||item.name||item.url),htmlNode('small','',item.url||item.state||''));
  content.style.cursor=item.url?'pointer':'default';
  if(item.url) content.onclick=()=>{setActivePanel(null);bridge?.openUrl(item.url);};
  el.append(content);
  if(actionLabel){ const btn=htmlNode('button','outline-btn',actionLabel);btn.onclick=onAction;el.append(btn); }
  if(secondaryAction){const btn=htmlNode('button','outline-btn','Open');btn.onclick=secondaryAction;el.append(btn);}
  return el;
}
function renderPanel() {
  const relevant = panel==='flow' ? [state.flow,state.pendingTransfers] : panel==='imports' ? [state.activeSpace,state.spaces,state.accounts,state.accountsError,importPreview] : panel==='updates' ? [state.version] : [state.settings,state.spaces,state.bookmarks,state.history,state.downloads,state.assistResult,state.activeSpace,state.filterStatus,state.tabs];
  const signature=JSON.stringify([panel,relevant]);if(signature===panelSignature)return;panelSignature=signature;
  const root=$('panelBody');root.replaceChildren();
  const titles={imports:'Import & saved accounts',updates:'Version & updates',settings:'Settings',bookmarks:'Bookmarks',history:'History',downloads:'Downloads',privacy:'Your privacy',spaces:'NIVQO Spaces',flow:'NIVQO Flow + Drop',boost:'NIVQO Boost',assist:'NIVQO Assist'};
  $('panelTitle').textContent=titles[panel]||'Nivqo';
  $('panelEyebrow').textContent=panel==='privacy'?'PRIVACY CONTROL':panel==='flow'?'ACCOUNT-FREE TRANSFERS':panel==='assist'?'LOCAL READING TOOLS':'YOUR BROWSER';
  if(panel==='imports') { renderImportsPanel(root);
  } else if(panel==='updates') { renderUpdatesPanel(root);
  } else if(panel==='settings') {
    const shortcuts=htmlNode('div','settings-links');shortcuts.append(actionButton('Import & saved accounts',async()=>setActivePanel('imports'),'outline-btn'),actionButton('Version & updates',async()=>setActivePanel('updates'),'outline-btn'));root.append(shortcuts);
    root.append(htmlNode('h3','','Appearance & search'));
    root.append(settingRow('Search engine','Search queries go to the provider you select.','select',state.settings.searchEngine,v=>bridge?.setSetting('searchEngine',v),[['duckduckgo','DuckDuckGo'],['brave','Brave Search'],['google','Google']]));
    root.append(settingRow('Appearance','Set the browser interface theme.','select',state.settings.theme,v=>bridge?.setSetting('theme',v),[['dark','Dark'],['light','Light']]));
    root.append(htmlNode('h3','','Privacy & data'));
    root.append(settingRow('Block known trackers','Uses local host rules and updated Ghostery filter lists when available.','toggle',state.settings.blockTrackers,v=>bridge?.setSetting('blockTrackers',v)));
    root.append(settingRow('Sleep inactive tabs (experimental)','After your chosen delay, background tabs reload when re-opened. Unsaved form data could be lost. Off by default.','toggle',state.settings.smartSleep,v=>bridge?.setSetting('smartSleep',v)));
    root.append(settingRow('Save local history','History stays on this computer and is not synced to any account.','toggle',state.settings.saveHistory,v=>bridge?.setSetting('saveHistory',v)));
    root.append(settingRow('Clear browsing data on exit','Clears locally stored site data, cookies and browsing history when the app quits.','toggle',state.settings.clearOnExit,v=>bridge?.setSetting('clearOnExit',v)));
    const btn=htmlNode('button','danger-button','Clear browser data now');
    btn.onclick=async()=>{ if(confirm('Clear site data, cookies, cache and local history? You may be logged out of websites.')) await bridge?.clearData(); };
    root.append(btn);
    root.append(htmlNode('p','help-text','Site permissions default to denied. Private tabs use an in-memory Chromium session. These features improve privacy but do not make you anonymous online. A production release needs independent security testing, signed builds, continuous Chromium updates and more complete cookie and fingerprinting protection.'));
  } else if(panel==='bookmarks') {
    root.append(htmlNode('p','help-text',`${state.bookmarks.length} locally stored bookmarks. Star a page using the toolbar to add it here.`));
    if(!state.bookmarks.some(b=>b.spaceId===(state.activeSpace||'personal'))) root.append(htmlNode('div','list-empty','No bookmarks yet — save a page using the ☆ icon.'));
    for(const item of state.bookmarks.filter(b=>b.spaceId===(state.activeSpace||'personal'))) root.append(entryRow(item,'☆','Open',()=>{setActivePanel(null);bridge?.openUrl(item.url);}));
  } else if(panel==='history') {
    const clear=htmlNode('button','outline-btn','Clear history');clear.onclick=()=>{if(confirm('Clear locally saved history?'))bridge?.clearHistory();};root.append(clear);
    if(!state.history.length)root.append(htmlNode('div','list-empty','No browsing history. Private tabs never appear here.'));
    for(const item of state.history.filter(h=>h.spaceId===(state.activeSpace||'personal')).slice(0,120))root.append(entryRow(item,'◷','Open',()=>{setActivePanel(null);bridge?.openUrl(item.url);}));
  } else if(panel==='downloads') {
    const open=htmlNode('button','outline-btn','Open Downloads folder');open.onclick=()=>call('open-downloads');root.append(open);
    root.append(htmlNode('p','help-text','Downloads are saved using the platform download dialogue.'));
    if(!state.downloads.length)root.append(htmlNode('div','list-empty','Your recent downloads will appear here.'));
    for(const item of state.downloads)root.append(entryRow({...item,title:item.name,url:null,state:`${item.state} · ${item.progress}%`},'⇩'));
  } else if(panel==='flow') { renderFlowPanel(root);
  } else if(panel==='spaces') { renderSpacesPanel(root);
  } else if(panel==='boost') { renderBoostPanel(root);
  } else if(panel==='assist') { renderAssistPanel(root);
  } else if(panel==='privacy') {
    const current=active();root.append(htmlNode('h3','',`${current?.blocked||0} known requests blocked on this tab`));
    root.append(htmlNode('p','help-text',`Protection mode: ${state.settings.blockTrackers ? (state.filterStatus==='full'?'Ghostery filter engine + fallback rules':'Offline fallback rules'):'Disabled'}. Request counts are approximate. Filter list retrieval contacts public list hosts occasionally.`));
    root.append(settingRow('Tracker blocking','Turn tracker filtering on or off globally.','toggle',state.settings.blockTrackers,v=>bridge?.setSetting('blockTrackers',v)));
    root.append(htmlNode('p','help-text','Do Not Track and Global Privacy Control request headers are sent, but websites may ignore them. VPN, Tor, full fingerprint protection, and audit-grade third-party cookie blocking are not included in this prototype.'));
  }
}
function navigate(value) {
  setActivePanel(null); call('navigate',value);
}
$('addTab').onclick=()=>{setActivePanel(null);bridge?.newTab({});};
$('incognitoTop').onclick=()=>{setActivePanel(null);bridge?.newTab({private:true});};
$('back').onclick=()=>call('back'); $('forward').onclick=()=>call('forward');
$('home').onclick=()=>{setActivePanel(null);call('home');};
$('reload').onclick=()=>call(active()?.loading?'stop':'reload');
$('star').onclick=()=>call('toggle-bookmark');
$('shield').onclick=()=>setActivePanel(panel==='privacy'?null:'privacy');
$('bookmarksButton').onclick=()=>setActivePanel(panel==='bookmarks'?null:'bookmarks');
$('historyButton').onclick=()=>setActivePanel(panel==='history'?null:'history');
$('downloadsButton').onclick=()=>setActivePanel(panel==='downloads'?null:'downloads');
$('settingsButton').onclick=()=>setActivePanel(panel==='settings'?null:'settings');
$('flowButton').onclick=()=>setActivePanel(panel==='flow'?null:'flow');
$('spacesButton').onclick=()=>setActivePanel(panel==='spaces'?null:'spaces');
$('assistButton').onclick=()=>setActivePanel(panel==='assist'?null:'assist');
$('boostButton').onclick=()=>setActivePanel(panel==='boost'?null:'boost');
$('importHome').onclick=()=>setActivePanel('imports');
$('updatesHome').onclick=()=>setActivePanel('updates');
$('flowHome').onclick=()=>setActivePanel('flow');
$('spacesHome').onclick=()=>setActivePanel('spaces');
$('shieldHome').onclick=()=>setActivePanel('privacy');
$('assistHome').onclick=()=>setActivePanel('assist');
$('spaceSelect').onchange=async()=>{setActivePanel(null);await bridge?.switchSpace($('spaceSelect').value);};
$('closePanel').onclick=()=>setActivePanel(null);
$('address').onfocus=()=>{focusedAddress=true;$('address').select();};
$('address').onblur=()=>{focusedAddress=false;renderToolbar();};
$('address').onkeydown=e=>{if(e.key==='Enter'){navigate($('address').value);$('address').blur();}if(e.key==='Escape'){$('address').blur();}};
$('homeSearchForm').onsubmit=e=>{e.preventDefault();navigate($('homeSearch').value);$('homeSearch').value='';};
for(const el of document.querySelectorAll('.quick'))el.onclick=()=>navigate(el.dataset.url);
$('findInput').oninput=()=>call('find',$('findInput').value);
$('findClose').onclick=()=>{$('findBar').classList.add('hidden');call('stop-find');};
function focusAddress(){ $('address').focus();$('address').select(); }
function focusFind(){ $('findBar').classList.remove('hidden');$('findInput').focus();$('findInput').select(); }
window.addEventListener('keydown',e=>{
  const ctrl=navigator.platform.toLowerCase().includes('mac')?e.metaKey:e.ctrlKey;
  const key=e.key.toLowerCase();
  if(ctrl && key==='l'){e.preventDefault();focusAddress();}
  else if(ctrl && key==='t'){e.preventDefault();setActivePanel(null);bridge?.newTab({});}
  else if(ctrl && key==='w'){e.preventDefault();if(active())bridge?.closeTab(active().id);}
  else if(ctrl && key==='f'){e.preventDefault();focusFind();}
  else if(ctrl && key==='r'){e.preventDefault();call('reload');}
  else if(ctrl && key==='d'){e.preventDefault();call('toggle-bookmark');}
  else if(ctrl && key==='p'){e.preventDefault();call('print');}
  else if(ctrl && key==='0'){e.preventDefault();call('zoom-reset');}
  else if(ctrl && (key==='=' || key==='+')){e.preventDefault();call('zoom-in');}
  else if(ctrl && key==='-'){e.preventDefault();call('zoom-out');}
  else if(ctrl && key==='tab' && state.tabs.length){e.preventDefault();const n=state.tabs.findIndex(t=>t.id===state.activeId);bridge?.activateTab(state.tabs[(n+(e.shiftKey?state.tabs.length-1:1))%state.tabs.length].id);}
  else if(ctrl && e.shiftKey && key==='n'){e.preventDefault();bridge?.newTab({private:true});}
  else if(e.altKey && key==='arrowleft'){e.preventDefault();call('back');}
  else if(e.altKey && key==='arrowright'){e.preventDefault();call('forward');}
  else if(key==='escape' && !$('findBar').classList.contains('hidden')){$('findClose').click();}
});
bridge?.onState(next=>{state=next;render();});
bridge?.onFlowError(message=>notify(message,true));
bridge?.onFocusAddress(focusAddress);
bridge?.onFocusFind(focusFind);
bridge?.getState().then(s=>{state=s;render();}).catch(()=>{});
render();
