'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const { once } = require('node:events');
const { FlowLink, parsePairCode } = require('../src/flow');
const secret = Buffer.alloc(32, 9).toString('base64url');
test('pairing codes reject credentials, query strings, fragments, alternate IP encodings and noncanonical secrets', () => {
  for (const value of [
    `nivqo-pair://user@127.0.0.1:1234/${secret}`,
    `nivqo-pair://127.0.0.1:1234/${secret}?tracking=1`,
    `nivqo-pair://127.0.0.1:1234/${secret}#fragment`,
    `nivqo-pair://127.1:1234/${secret}`,
    `nivqo-pair://192.168.001.2:1234/${secret}`,
    `nivqo-pair://127.0.0.1:1234/${secret.slice(0,-1)}B`
  ]) assert.throws(()=>parsePairCode(value));
});
test('invalid unauthenticated frame closes the listener and invalidates the pairing secret',async t=>{
  const host = new FlowLink();host.on('error',()=>{});t.after(()=>host.disconnect());
  const code=await host.host({bindHost:'127.0.0.1',advertiseHost:'127.0.0.1'});
  const {port}=parsePairCode(code);const socket=net.createConnection({host:'127.0.0.1',port});socket.on('error',()=>{});t.after(()=>socket.destroy());
  await once(socket,'connect');const gone=new Promise(resolve=>host.once('disconnected',resolve));
  const header=Buffer.alloc(4);header.writeUInt32BE(4097);socket.write(header);await gone;
  assert.equal(host.server,null);assert.equal(host.pairCode,'');assert.equal(host.secret,null);
});
test('encrypted file bytes survive a real socket transfer',async t=>{
  const host=new FlowLink(),client=new FlowLink();host.on('error',()=>{});client.on('error',()=>{});t.after(()=>{host.disconnect();client.disconnect();});
  const code=await host.host({bindHost:'127.0.0.1',advertiseHost:'127.0.0.1'});const ready=once(host,'connected');await client.join(code);await ready;
  const bytes=Buffer.alloc(128*1024);for(let i=0;i<bytes.length;i++)bytes[i]=i%256;
  const received=once(host,'message');client.send('drop-file',{name:'fixture.bin',data:bytes.toString('base64')});
  const [message]=await received;assert.deepEqual(Buffer.from(message.data.data,'base64'),bytes);
});
