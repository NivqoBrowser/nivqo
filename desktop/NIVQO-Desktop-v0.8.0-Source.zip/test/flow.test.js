const { test } = require('node:test');
const assert = require('node:assert/strict');
const { once } = require('node:events');
const { FlowLink, parsePairCode } = require('../src/flow');
test('rejects invalid/untrusted pairing codes', () => {
 assert.throws(() => parsePairCode('https://evil.com'), /Invalid/);
 assert.throws(() => parsePairCode('nivqo-pair://8.8.8.8:2323/'+'a'.repeat(43)), /private LAN/);
});
test('pairs without an account and exchanges encrypted tab/text in both directions', async () => {
 const host = new FlowLink(), client = new FlowLink();
 try {
  const code = await host.host({bindHost:'127.0.0.1',advertiseHost:'127.0.0.1'});
  assert.ok(code.startsWith('nivqo-pair://127.0.0.1:'));
  const ready = once(host,'connected');
  await client.join(code); await ready;
  const got1 = once(host,'message');
  client.send('flow-tab',{url:'https://example.org/a',title:'Example',scrollY:42});
  assert.deepEqual((await got1)[0],{type:'flow-tab',data:{url:'https://example.org/a',title:'Example',scrollY:42}});
  const got2 = once(client,'message');
  host.send('drop-text',{text:'hello from desktop'});
  assert.deepEqual((await got2)[0],{type:'drop-text',data:{text:'hello from desktop'}});
 } finally {host.disconnect();client.disconnect();}
});
test('rejects a wrong pairing secret (no silent connection)', async () => {
 const host = new FlowLink(), client = new FlowLink();
 host.on('error', () => {}); client.on('error', () => {});
 try {
  const code = await host.host({bindHost:'127.0.0.1',advertiseHost:'127.0.0.1'});
  const wrong = code.replace(/[^/]+$/, Buffer.alloc(32, 0x42).toString('base64url'));
  await assert.rejects(client.join(wrong), /Pairing|authentication|closed/i);
  assert.equal(client.connected, false);
  assert.equal(host.connected, false);
 } finally { host.disconnect(); client.disconnect(); }
});
test('rejects oversized file payloads', async () => {
 const host = new FlowLink(), client = new FlowLink();
 try {
  const code = await host.host({bindHost:'127.0.0.1',advertiseHost:'127.0.0.1'});
  const ready = once(host,'connected'); await client.join(code); await ready;
  assert.throws(() => client.send('drop-file',{name:'too-big.bin',data:Buffer.alloc(4*1024*1024+1).toString('base64')}), /4 MB/);
 } finally { host.disconnect(); client.disconnect(); }
});
