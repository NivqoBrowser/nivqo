'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseBookmarks, parsePasswords, createImportService } = require('../src/imports');

test('bookmark parser reads exports without script execution or dangerous URLs', () => {
  const result = parseBookmarks('<!DOCTYPE NETSCAPE-Bookmark-file-1><DL><A HREF="https://example.com/?a=1&amp;b=2">A &amp; B</A><A HREF="javascript:alert(1)">Bad</A><script><A HREF="https://wrong.test">Hidden</A></script><A HREF="https://user:password@example.com">Credentials</A></DL>');
  assert.equal(result.total, 3);assert.equal(result.records.length, 1);
  assert.deepEqual(result.records[0], { url:'https://example.com/?a=1&b=2', title:'A & B' });
  const json = parseBookmarks(JSON.stringify({ roots:{ bookmark_bar:{ children:[{type:'url',name:'Saved',url:'https://example.org'}] } } }));
  assert.equal(json.records[0].url,'https://example.org/');
});
test('CSV supports commas, quotes, CRLF and multiline passwords; unsafe entries skipped', () => {
  const parsed=parsePasswords('name,url,username,password\r\n"Work, app",https://example.org,alice,"p,""quote""\nnext"\r\nBad,javascript:x,a,b\r\n');
  assert.equal(parsed.records.length,1);assert.equal(parsed.skipped,1);
  assert.equal(parsed.records[0].password,'p,"quote"\nnext');
  assert.throws(()=>parsePasswords('url,username,password\nx,y,"broken'),/quote/);
  assert.throws(()=>parsePasswords('hello,there\nx,y'),/columns/);
});
function setup(t, text, kind='passwords', encrypted=true) {
  const folder=fs.mkdtempSync(path.join(os.tmpdir(),'nivqo-import-test-'));
  const file=path.join(folder,kind==='passwords'?'fixture.csv':'fixture.html');fs.writeFileSync(file,text);
  let clipboard='',timer,active='personal',clock=1000;
  const store={bookmarks:[],spaces:[{id:'personal'},{id:'work'}]};
  const key=crypto.randomBytes(32);
  const safeStorage={isEncryptionAvailable:()=>encrypted,encryptString(value){const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv);const data=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),data]);},decryptString(bytes){const decipher=crypto.createDecipheriv('aes-256-gcm',key,bytes.subarray(0,12));decipher.setAuthTag(bytes.subarray(12,28));return Buffer.concat([decipher.update(bytes.subarray(28)),decipher.final()]).toString();}};
  const service=createImportService({app:{getPath:()=>folder},dialog:{showOpenDialog:async()=>({filePaths:[file]})},safeStorage,
    clipboard:{writeText:v=>clipboard=v,readText:()=>clipboard,clear:()=>clipboard=''},getStore:()=>store,save:()=>{},publish:()=>{},getActiveSpace:()=>active,getWindow:()=>null,now:()=>clock,
    setTimer:fn=>{timer=fn;return 1},clearTimer:()=>{}});
  t.after(()=>{service.dispose();fs.rmSync(folder,{recursive:true,force:true});});
  return {service,store,folder,setSpace:v=>active=v,setTime:v=>clock=v,setClipboard:v=>clipboard=v,getClipboard:()=>clipboard,expire:()=>timer()};
}
const csv='name,url,username,password\nExample,https://example.com,alice,not-a-real-password\nExample,https://example.com,alice,duplicate\n';
test('preview requires confirmation, redacts passwords, deduplicates, encrypts vault',async t=>{
  const env=setup(t,csv);const preview=await env.service.preview('passwords');
  assert.equal(preview.toImport,1);assert.equal(preview.duplicates,1);assert.ok(!JSON.stringify(preview).includes('not-a-real-password'));
  assert.equal(env.service.listAccounts().length,0);
  const result=await env.service.commit(preview.token);assert.equal(result.imported,1);
  assert.ok(!fs.readFileSync(path.join(env.folder,'accounts-v1.json'),'utf8').includes('not-a-real-password'));
  const [account]=env.service.listAccounts();assert.ok(!('encryptedPassword' in account));
  env.service.copyAccount(account.id,'password');assert.equal(env.getClipboard(),'not-a-real-password');
  env.expire();assert.equal(env.getClipboard(),'');
  env.service.copyAccount(account.id,'username');env.setClipboard('newer content');env.expire();assert.equal(env.getClipboard(),'newer content');
  env.setSpace('work');assert.throws(()=>env.service.copyAccount(account.id,'password'),/current Space/);
  env.setSpace('personal');env.service.deleteAccount(account.id);assert.equal(env.service.listAccounts().length,0);
  await assert.rejects(()=>env.service.commit(preview.token),/no longer/);
});
test('password import fails closed when OS encryption is unavailable',async t=>{
  const env=setup(t,csv,'passwords',false);await assert.rejects(()=>env.service.preview('passwords'),/encryption/);
});
test('cancelled and expired previews do not change bookmarks',async t=>{
  const env=setup(t,'<A HREF="https://example.com">Example</A>','bookmarks');
  const first=await env.service.preview('bookmarks');env.service.cancel(first.token);
  await assert.rejects(()=>env.service.commit(first.token),/no longer/);assert.equal(env.store.bookmarks.length,0);
  const second=await env.service.preview('bookmarks');env.setTime(999999);
  await assert.rejects(()=>env.service.commit(second.token),/expired/);assert.equal(env.store.bookmarks.length,0);
});
test('bookmark import remains bound to reviewed Space and skips duplicates',async t=>{
  const env=setup(t,'<A HREF="https://example.com">Example</A><A HREF="https://example.com">Duplicate</A>','bookmarks');
  const preview=await env.service.preview('bookmarks');env.setSpace('work');await env.service.commit(preview.token);
  assert.equal(env.store.bookmarks.length,1);assert.equal(env.store.bookmarks[0].spaceId,'personal');
});
