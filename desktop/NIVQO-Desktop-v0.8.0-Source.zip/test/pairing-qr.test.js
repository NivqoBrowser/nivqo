'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const QRCode = require('qrcode');
const { createPairQr, decodePairQr, validatePng } = require('../src/pairing-qr');
const code = 'nivqo-pair://192.168.1.42:48123/' + Buffer.alloc(32, 7).toString('base64url');
function pixels(text) {
  const qr = QRCode.create(text, { errorCorrectionLevel: 'M' });
  const size = (qr.modules.size + 8) * 6;
  const rgba = new Uint8ClampedArray(size * size * 4).fill(255);
  for (let y = 0; y < qr.modules.size; y++) for (let x = 0; x < qr.modules.size; x++) {
    if (!qr.modules.get(y, x)) continue;
    for (let dy = 0; dy < 6; dy++) for (let dx = 0; dx < 6; dx++) {
      const p = (((y + 4) * 6 + dy) * size + (x + 4) * 6 + dx) * 4;
      rgba[p] = rgba[p + 1] = rgba[p + 2] = 0;
    }
  }
  return { rgba, size };
}
test('pairing URI survives QR generation and decoding exactly', async () => {
  const url = await createPairQr(code);
  assert.match(url, /^data:image\/png;base64,/);
  const png = Buffer.from(url.split(',')[1], 'base64');
  assert.deepEqual(validatePng(png), { width: 384, height: 384 });
  const { rgba, size } = pixels(code);
  assert.equal(decodePairQr(rgba, size, size), code);
});
test('QR decoder rejects websites instead of treating them as pairing codes', () => {
  const { rgba, size } = pixels('https://example.com/');
  assert.throws(() => decodePairQr(rgba, size, size), /Invalid pairing code/);
});
test('PNG guard rejects oversized dimensions and non-PNG data', async () => {
  assert.throws(() => validatePng(Buffer.alloc(40)), /PNG/);
  const png = Buffer.from((await createPairQr(code)).split(',')[1], 'base64');
  png.writeUInt32BE(50000, 16);
  assert.throws(() => validatePng(png), /dimensions/);
});
